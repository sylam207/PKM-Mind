import { showStatus } from "./state.js";

function getRootNode(state) {
  return state.nodes.find((n) => !n.parent) || null;
}

function getNodeById(state, nodeId) {
  return state.nodes.find((node) => node.id === nodeId) || null;
}

function getVisibleChildren(node) {
  if (node.collapsed) {
    return [];
  }
  return node.children;
}

function isDescendantOrSelf(node, ancestor) {
  if (!node || !ancestor) {
    return false;
  }

  let current = node;
  while (current) {
    if (current === ancestor) {
      return true;
    }
    current = current.parent;
  }
  return false;
}

function traverseVisible(root, visit) {
  if (!root) {
    return;
  }

  visit(root);
  for (const child of getVisibleChildren(root)) {
    traverseVisible(child, visit);
  }
}

function countVisibleLeaves(node) {
  const visibleChildren = getVisibleChildren(node);
  if (visibleChildren.length === 0) {
    return 1;
  }
  return visibleChildren.map(countVisibleLeaves).reduce((a, b) => a + b, 0);
}

function collectVisibleNodes(state) {
  const root = getRootNode(state);
  const nodes = [];
  traverseVisible(root, (node) => nodes.push(node));
  return nodes;
}

function collectVisibleLinks(state) {
  const links = [];
  const root = getRootNode(state);
  traverseVisible(root, (node) => {
    if (node.collapsed) {
      return;
    }
    for (const child of node.children) {
      links.push({ from: node, to: child });
    }
  });
  return links;
}

function rebuildVisibilityCaches(state) {
  const visibleNodes = collectVisibleNodes(state);
  const visibleLinks = collectVisibleLinks(state);
  state.visibleNodeIds = new Set(visibleNodes.map((node) => node.id));
  state.visibleLinkKeys = new Set(visibleLinks.map((link) => `${link.from.id}->${link.to.id}`));
  return { visibleNodes, visibleLinks };
}

function layoutHorizontal(state, root, { spacingY, horizontalPadding, baseX }) {
  for (const node of state.nodes) {
    node.width = node.calculateWidth();
  }

  const canvasCenterY = state.canvas.height / 2;
  const visibleLeafCount = countVisibleLeaves(root);
  const yRef = {
    value: canvasCenterY - (visibleLeafCount * spacingY) / 2
  };

  function layoutNode(node, depth = 0) {
    if (!node.pinned) {
      if (node.parent) {
        node.x = node.parent.x + node.parent.width + horizontalPadding + depth * 2;
      } else {
        node.x = baseX;
      }
    }

    const visibleChildren = getVisibleChildren(node);

    if (visibleChildren.length === 0) {
      if (!node.pinned) {
        node.y = yRef.value;
      }
      yRef.value += node.height + spacingY;
      return node.y;
    }

    const childYs = visibleChildren.map((child) => layoutNode(child, depth + 1));
    const avgY = childYs.reduce((a, b) => a + b, 0) / childYs.length;
    if (!node.pinned) {
      node.y = avgY;
    }
    return node.y;
  }

  layoutNode(root);
}

function layoutRadial(state, root) {
  for (const node of state.nodes) {
    node.width = node.calculateWidth();
  }

  const centerX = state.canvas.width * 0.45;
  const centerY = state.canvas.height * 0.5;
  const radiusStep = 120;

  function assignPolar(node, startAngle, endAngle, depth) {
    const angle = (startAngle + endAngle) / 2;
    const radius = depth * radiusStep;

    if (!node.pinned) {
      if (depth === 0) {
        node.x = centerX;
        node.y = centerY;
      } else {
        node.x = centerX + Math.cos(angle) * radius;
        node.y = centerY + Math.sin(angle) * radius;
      }
    }

    const visibleChildren = getVisibleChildren(node);
    if (visibleChildren.length === 0) {
      return;
    }

    const totalLeaves = visibleChildren.map((child) => countVisibleLeaves(child)).reduce((a, b) => a + b, 0);
    let cursor = startAngle;

    for (const child of visibleChildren) {
      const childLeaves = countVisibleLeaves(child);
      const span = ((endAngle - startAngle) * childLeaves) / totalLeaves;
      assignPolar(child, cursor, cursor + span, depth + 1);
      cursor += span;
    }
  }

  assignPolar(root, -Math.PI * 0.85, Math.PI * 0.85, 0);
}

function runLayoutForMode(state, root) {
  if (state.layoutMode === "radial") {
    layoutRadial(state, root);
    return;
  }

  if (state.layoutMode === "compact") {
    layoutHorizontal(state, root, {
      spacingY: 36,
      horizontalPadding: 28,
      baseX: 90
    });
    return;
  }

  layoutHorizontal(state, root, {
    spacingY: 60,
    horizontalPadding: 40,
    baseX: 100
  });
}

export function autoNumberNodes(state) {
  const root = getRootNode(state);
  if (!root) {
    return;
  }

  root.numbering = "";

  function assignNumbers(node, prefix = "") {
    node.children.forEach((child, index) => {
      const number = prefix ? `${prefix}.${index + 1}` : `${index + 1}`;
      child.numbering = `${number}.`;
      assignNumbers(child, number);
    });
  }

  assignNumbers(root);
}

export function autoLayout(state) {
  const root = getRootNode(state);
  if (!root) {
    return;
  }

  runLayoutForMode(state, root);
  autoNumberNodes(state);
  rebuildVisibilityCaches(state);
}

export function calculateInsertionZones(state) {
  rebuildVisibilityCaches(state);
  state.nodeZones = [];
  const childrenByParent = new Map();

  state.nodes.forEach((node) => {
    if (!state.visibleNodeIds.has(node.id)) {
      return;
    }
    if (node.parent) {
      if (node.parent.collapsed) {
        return;
      }
      if (!childrenByParent.has(node.parent)) {
        childrenByParent.set(node.parent, []);
      }
      childrenByParent.get(node.parent).push(node);
    }
  });

  childrenByParent.forEach((children, parent) => {
    const sortedChildren = [...children].sort((a, b) => a.y - b.y);
    const standardZoneHeight = 30;

    sortedChildren.forEach((child, index) => {
      const isLastChild = index === sortedChildren.length - 1;
      const isFirstChild = index === 0;
      const zoneWidth = child.x - (parent.x + parent.width) + child.width;

      state.nodeZones.push({
        type: "before",
        parent,
        targetNode: child,
        actualIndex: parent.children.indexOf(child),
        x: parent.x + parent.width,
        y: child.y - standardZoneHeight,
        width: zoneWidth,
        height: standardZoneHeight,
        color: "rgba(255, 0, 0, 0.2)"
      });

      if (!isFirstChild) {
        const prevChild = sortedChildren[index - 1];
        const gapStart = prevChild.y + prevChild.height + standardZoneHeight;
        const gapEnd = child.y - standardZoneHeight;

        if (gapEnd > gapStart) {
          state.nodeZones.push({
            type: "extended-before",
            parent,
            targetNode: child,
            actualIndex: parent.children.indexOf(child),
            x: parent.x + parent.width,
            y: gapStart,
            width: zoneWidth,
            height: gapEnd - gapStart,
            color: "rgba(255, 0, 0, 0.2)"
          });
        }
      }

      if (isLastChild) {
        state.nodeZones.push({
          type: "after",
          parent,
          targetNode: child,
          actualIndex: parent.children.length,
          x: parent.x + parent.width,
          y: child.y + child.height,
          width: zoneWidth,
          height: standardZoneHeight,
          color: "rgba(0, 255, 0, 0.2)"
        });
      }
    });
  });

  state.nodes.forEach((node) => {
    if (!state.visibleNodeIds.has(node.id)) {
      return;
    }

    if (node.children.length === 0 || node.collapsed) {
      state.nodeZones.push({
        type: "child",
        parent: node,
        targetNode: null,
        actualIndex: 0,
        x: node.x + node.width,
        y: node.y,
        width: node.width,
        height: node.height,
        color: "rgba(255, 255, 0, 0.15)"
      });
    }
  });
}

export function getVisibleNodes(state) {
  return collectVisibleNodes(state);
}

export function getVisibleLinks(state) {
  return collectVisibleLinks(state);
}

export function isLinkVisible(state, fromNode, toNode) {
  return state.visibleLinkKeys.has(`${fromNode.id}->${toNode.id}`);
}

export function getFocusNode(state) {
  return state.focusNodeId === null ? null : getNodeById(state, state.focusNodeId);
}

export function isNodeDimmedByFocus(state, node) {
  const focusNode = getFocusNode(state);
  if (!focusNode) {
    return false;
  }
  return !isDescendantOrSelf(node, focusNode);
}

export function isLinkDimmedByFocus(state, fromNode, toNode) {
  const focusNode = getFocusNode(state);
  if (!focusNode) {
    return false;
  }
  return !(isDescendantOrSelf(fromNode, focusNode) && isDescendantOrSelf(toNode, focusNode));
}

export function countHiddenDescendants(node) {
  let total = 0;

  function walk(current) {
    for (const child of current.children) {
      total += 1;
      walk(child);
    }
  }

  walk(node);
  return total;
}

export function centerMindmap(state, requestDrawFn) {
  if (state.nodes.length === 0) {
    return;
  }

  const rootNode = getRootNode(state);
  if (!rootNode) {
    return;
  }

  const focusNode = getFocusNode(state);
  const anchorNode = focusNode || rootNode;

  const visibleNodes = collectVisibleNodes(state);

  let minY = Infinity;
  let maxY = -Infinity;

  for (const node of visibleNodes) {
    minY = Math.min(minY, node.y);
    maxY = Math.max(maxY, node.y + node.height);
  }

  const mindmapCenterY = (minY + maxY) / 2;
  const canvasCenterY = state.canvas.height / 2;
  const leftPadding = state.canvas.width * 0.15;

  state.viewOffsetX = leftPadding - anchorNode.x * state.viewScale;
  state.viewOffsetY = canvasCenterY - mindmapCenterY * state.viewScale;
  requestDrawFn();

  const now = Date.now();
  state.centerButtonClicks.push(now);
  state.centerButtonClicks = state.centerButtonClicks.filter((timestamp) => now - timestamp < 3000);

  if (state.centerButtonClicks.length >= 5) {
    state.debugShowZones = !state.debugShowZones;
    state.centerButtonClicks = [];
    showStatus(state, state.debugShowZones ? "Debug zones enabled" : "Debug zones disabled");
    requestDrawFn();
  }
}
