export function cloneJson(value) {
  return JSON.parse(JSON.stringify(value));
}

function normalizeNodeWithIds(nodeData, nextIdRef) {
  const normalized = { ...nodeData };

  if (!Number.isInteger(normalized.id)) {
    normalized.id = nextIdRef.value;
    nextIdRef.value += 1;
  } else {
    nextIdRef.value = Math.max(nextIdRef.value, normalized.id + 1);
  }

  const children = Array.isArray(normalized.children) ? normalized.children : [];
  normalized.children = children.map((child) => normalizeNodeWithIds(child, nextIdRef));
  return normalized;
}

export function normalizeJsonWithStableIds(jsonData, startId = 1) {
  const normalized = cloneJson(jsonData || {});
  const nextIdRef = { value: Math.max(1, startId) };
  const rootNodes = Array.isArray(normalized.nodes) ? normalized.nodes : [];
  normalized.nodes = rootNodes.map((node) => normalizeNodeWithIds(node, nextIdRef));

  return {
    normalized,
    nextId: nextIdRef.value
  };
}

export function collectNodesById(nodeList, targetMap = new Map()) {
  for (const node of nodeList || []) {
    targetMap.set(node.id, node);
    if (Array.isArray(node.children) && node.children.length > 0) {
      collectNodesById(node.children, targetMap);
    }
  }
  return targetMap;
}

export function mergeHiddenBranchesById(visibleData, originalData) {
  const originalById = collectNodesById(originalData.nodes || []);

  function mergeNode(visibleNode) {
    const mergedChildren = (visibleNode.children || []).map((child) => mergeNode(child));
    const visibleChildIds = new Set(mergedChildren.map((child) => child.id));

    const originalNode = originalById.get(visibleNode.id);
    const hiddenChildren = originalNode && Array.isArray(originalNode.children)
      ? originalNode.children.filter((child) => child.hidden && !visibleChildIds.has(child.id))
      : [];

    return {
      id: visibleNode.id,
      text: visibleNode.text,
      children: [...mergedChildren, ...cloneJson(hiddenChildren)]
    };
  }

  return {
    nodes: (visibleData.nodes || []).map((node) => mergeNode(node)),
    viewScale: visibleData.viewScale,
    viewOffsetX: visibleData.viewOffsetX,
    viewOffsetY: visibleData.viewOffsetY
  };
}
