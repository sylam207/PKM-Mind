// Legacy entry retained for compatibility.
// The app now starts from main.js as an ES module.
console.info("Mindmap app entry moved to main.js");
