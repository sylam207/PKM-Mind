export function createAppState() {
  const canvas = document.getElementById("mindmap");
  const ctx = canvas.getContext("2d");

  return {
    canvas,
    ctx,
    renameInput: document.getElementById("renameInput"),
    reorderUp: document.getElementById("reorderUp"),
    reorderDown: document.getElementById("reorderDown"),
    statusMessage: document.getElementById("statusMessage"),
    loadingIndicator: document.getElementById("loadingIndicator"),
    loadingText: document.getElementById("loadingText"),
    toolbar: document.getElementById("toolbar"),
    toolbarToggle: document.getElementById("toolbarToggle"),
    saveBtn: document.getElementById("saveBtn"),
    addBtn: document.getElementById("addBtn"),
    deleteBtn: document.getElementById("deleteBtn"),
    centerBtn: document.getElementById("centerBtn"),
    undoBtn: document.getElementById("undoBtn"),
    clearBtn: document.getElementById("clearBtn"),
    collapseBtn: document.getElementById("collapseBtn"),
    focusBtn: document.getElementById("focusBtn"),
    layoutBtn: document.getElementById("layoutBtn"),
    pinBtn: document.getElementById("pinBtn"),
    themeBtn: document.getElementById("themeBtn"),

    originalJsonData: null,
    nodes: [],
    links: [],
    selectedNode: null,
    draggingNode: null,
    ghostX: 0,
    ghostY: 0,
    offsetX: 0,
    offsetY: 0,
    isDragging: false,
    showGhostNode: false,
    debugShowZones: false,
    nodeZones: [],

    viewOffsetX: 0,
    viewOffsetY: 0,
    viewScale: 1,
    isPanning: false,
    panStartX: 0,
    panStartY: 0,

    lastTouchDist: null,
    lastTapTime: 0,
    lastTapNode: null,

    potentialParent: null,
    insertPosition: -1,

    history: [],
    maxHistorySteps: 20,

    currentGistId: null,
    hasUnsavedChanges: false,
    centerButtonClicks: [],

    animationFrameRequested: false,
    nextNodeId: 1,

    layoutMode: "horizontal",
    focusNodeId: null,
    visibleNodeIds: new Set(),
    visibleLinkKeys: new Set(),
    lastDragEndAt: 0,
    lastPointerDownNodeId: null,

    branchTheme: "Calm",
    layoutTransitionActive: false
  };
}

const BRANCH_THEMES = {
  Calm: {
    nodeFills: ["#eef2ff", "#e0f2fe", "#dcfce7", "#fef3c7", "#ffe4e6", "#ede9fe"],
    nodeBorders: ["#4f46e5", "#0284c7", "#16a34a", "#d97706", "#e11d48", "#7c3aed"],
    nodeTexts: ["#312e81", "#0c4a6e", "#14532d", "#7c2d12", "#881337", "#4c1d95"],
    linkColors: ["#6366f1", "#0284c7", "#16a34a", "#d97706", "#e11d48", "#7c3aed"]
  },
  Vivid: {
    nodeFills: ["#dbeafe", "#cffafe", "#d9f99d", "#fed7aa", "#fecdd3", "#ddd6fe"],
    nodeBorders: ["#2563eb", "#0e7490", "#65a30d", "#ea580c", "#e11d48", "#7c3aed"],
    nodeTexts: ["#1e3a8a", "#164e63", "#365314", "#7c2d12", "#9f1239", "#5b21b6"],
    linkColors: ["#2563eb", "#06b6d4", "#65a30d", "#f97316", "#f43f5e", "#8b5cf6"]
  },
  Minimal: {
    nodeFills: ["#f8fafc", "#f1f5f9", "#e2e8f0", "#f1f5f9", "#f8fafc", "#e2e8f0"],
    nodeBorders: ["#334155", "#475569", "#64748b", "#475569", "#334155", "#64748b"],
    nodeTexts: ["#0f172a", "#0f172a", "#0f172a", "#0f172a", "#0f172a", "#0f172a"],
    linkColors: ["#334155", "#475569", "#64748b", "#475569", "#334155", "#64748b"]
  }
};

export function getBranchTheme(state) {
  return BRANCH_THEMES[state.branchTheme] || BRANCH_THEMES.Calm;
}

export function setCanvasSize(state) {
  state.canvas.width = window.innerWidth;
  state.canvas.height = window.innerHeight;
}

export function createNode(state, text, explicitId = null) {
  const resolvedId = explicitId ?? state.nextNodeId;
  state.nextNodeId = Math.max(state.nextNodeId, resolvedId + 1);

  const node = {
    id: resolvedId,
    text,
    numbering: "",
    x: 0,
    y: 0,
    renderX: 0,
    renderY: 0,
    height: 40,
    width: 100,
    parent: null,
    children: [],
    collapsed: false,
    pinned: false,
    calculateWidth() {
      state.ctx.font = "600 14px Manrope";
      const label = this.numbering ? `${this.numbering} ${this.text}` : this.text;
      return Math.max(100, state.ctx.measureText(label).width + 20);
    },
    draw(isGhost = false) {
      const theme = getBranchTheme(state);

      let depth = 0;
      let current = this.parent;
      while (current) {
        depth += 1;
        current = current.parent;
      }

      const paletteIndex = depth % theme.nodeFills.length;
      const palette = {
        fill: theme.nodeFills[paletteIndex],
        border: theme.nodeBorders[paletteIndex],
        text: theme.nodeTexts[paletteIndex]
      };
      this.width = this.calculateWidth();
      const label = this.numbering ? `${this.numbering} ${this.text}` : this.text;

      if (!Number.isFinite(this.renderX)) {
        this.renderX = this.x;
      }
      if (!Number.isFinite(this.renderY)) {
        this.renderY = this.y;
      }

      state.ctx.globalAlpha = isGhost ? 0.4 : 1;
      const isSelected = this === state.selectedNode && !isGhost;
      state.ctx.fillStyle = isSelected ? "#2563eb" : palette.fill;
      state.ctx.strokeStyle = isSelected ? "#1d4ed8" : palette.border;
      state.ctx.lineWidth = isSelected ? 2.2 : this.collapsed ? 2 : 1.6;
      const radius = 10;

      const x = isGhost ? state.ghostX : this.renderX;
      const y = isGhost ? state.ghostY : this.renderY;

      state.ctx.beginPath();
      state.ctx.moveTo(x + radius, y);
      state.ctx.lineTo(x + this.width - radius, y);
      state.ctx.quadraticCurveTo(x + this.width, y, x + this.width, y + radius);
      state.ctx.lineTo(x + this.width, y + this.height - radius);
      state.ctx.quadraticCurveTo(x + this.width, y + this.height, x + this.width - radius, y + this.height);
      state.ctx.lineTo(x + radius, y + this.height);
      state.ctx.quadraticCurveTo(x, y + this.height, x, y + this.height - radius);
      state.ctx.lineTo(x, y + radius);
      state.ctx.quadraticCurveTo(x, y, x + radius, y);
      state.ctx.closePath();

      state.ctx.shadowColor = isSelected ? "rgba(37, 99, 235, 0.38)" : "rgba(15, 23, 42, 0.08)";
      state.ctx.shadowBlur = isSelected ? 12 : 5;
      state.ctx.shadowOffsetY = isSelected ? 3 : 2;
      state.ctx.fill();
      state.ctx.shadowColor = "transparent";
      state.ctx.stroke();

      state.ctx.fillStyle = isSelected ? "#ffffff" : palette.text;
      state.ctx.font = "600 14px Manrope";
      state.ctx.textAlign = "center";
      state.ctx.textBaseline = "middle";
      state.ctx.fillText(label, x + this.width / 2, y + this.height / 2);

      if (this.pinned && !isGhost) {
        state.ctx.fillStyle = "#0f766e";
        state.ctx.beginPath();
        state.ctx.arc(x + 10, y + 10, 4, 0, Math.PI * 2);
        state.ctx.fill();
      }

      state.ctx.globalAlpha = 1;
    },
    isInside(mx, my) {
      const hitX = Number.isFinite(this.renderX) ? this.renderX : this.x;
      const hitY = Number.isFinite(this.renderY) ? this.renderY : this.y;
      return mx >= hitX && mx <= hitX + this.width && my >= hitY && my <= hitY + this.height;
    }
  };

  node.width = node.calculateWidth();
  node.renderX = node.x;
  node.renderY = node.y;
  return node;
}

export function toCanvasCoords(state, x, y) {
  return {
    x: (x - state.viewOffsetX) / state.viewScale,
    y: (y - state.viewOffsetY) / state.viewScale
  };
}

export function showStatus(state, message, duration = 3000) {
  state.statusMessage.textContent = message;
  state.statusMessage.classList.add("visible");

  setTimeout(() => {
    state.statusMessage.classList.remove("visible");
  }, duration);
}

export function showLoading(state, text) {
  state.loadingText.textContent = text || "Loading...";
  state.loadingIndicator.style.display = "block";
}

export function hideLoading(state) {
  state.loadingIndicator.style.display = "none";
}

export function updateUndoButton(state) {
  state.undoBtn.disabled = state.history.length <= 1;
}

export function updateDeleteButton(state) {
  const hasSelection = !!state.selectedNode;
  state.deleteBtn.disabled = !hasSelection;
  state.focusBtn.disabled = !hasSelection;
  state.pinBtn.disabled = !hasSelection;
  state.collapseBtn.disabled = !hasSelection || state.selectedNode.children.length === 0;
}

export function setUnsavedChanges(state, value) {
  state.hasUnsavedChanges = value;
  state.saveBtn.classList.toggle("highlight", state.hasUnsavedChanges);
}

export function findNodeAt(state, mx, my) {
  for (const node of state.nodes) {
    if (node.isInside(mx, my)) {
      return node;
    }
  }
  return null;
}
