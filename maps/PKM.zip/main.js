import { bindControls, initializeFromQuery, setupCanvasEvents, setupKeyboardShortcuts, setupToolbar } from "./input.js";
import { requestDraw } from "./rendering.js";
import { createAppState, setCanvasSize, updateDeleteButton } from "./state.js";

// state is created inside init() so DOM elements exist when getElementById is called.
let state;

function init() {
  state = createAppState();
  setCanvasSize(state);

  window.addEventListener("beforeunload", (e) => {
    if (!state.hasUnsavedChanges) {
      return;
    }
    const message = "You have unsaved changes. Are you sure you want to leave?";
    e.returnValue = message;
    return message;
  });

  bindControls(state);
  setupToolbar(state);
  setupKeyboardShortcuts(state);
  setupCanvasEvents(state);

  initializeFromQuery(state);
  updateDeleteButton(state);
  requestDraw(state);
}

// DOMContentLoaded fires before load and guarantees the HTML is parsed.
// Fallback to running immediately if already parsed (file:// fast-load edge case).
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
