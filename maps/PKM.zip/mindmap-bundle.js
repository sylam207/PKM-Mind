// mindmap-bundle.js — single-file bundle (no ES modules, works on file://)
(function () {
  "use strict";

  // ── tree-utils.js ──────────────────────────────────────────────────────────

  function cloneJson(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function normalizeNodeWithIds(nodeData, nextIdRef) {
    const normalized = { ...nodeData };
    if (!Number.isInteger(normalized.id)) {
      normalized.id = nextIdRef.value;
      nextIdRef.value += 1;
    } else {
      nextIdRef.value = Math.max(nextIdRef.value, normalized.id + 1);
    }
    const children = Array.isArray(normalized.children) ? normalized.children : [];
    normalized.children = children.map((child) => normalizeNodeWithIds(child, nextIdRef));
    return normalized;
  }

  function normalizeJsonWithStableIds(jsonData, startId = 1) {
    const normalized = cloneJson(jsonData || {});
    const nextIdRef = { value: Math.max(1, startId) };
    const rootNodes = Array.isArray(normalized.nodes) ? normalized.nodes : [];
    normalized.nodes = rootNodes.map((node) => normalizeNodeWithIds(node, nextIdRef));
    return { normalized, nextId: nextIdRef.value };
  }

  function collectNodesById(nodeList, targetMap = new Map()) {
    for (const node of nodeList || []) {
      targetMap.set(node.id, node);
      if (Array.isArray(node.children) && node.children.length > 0) {
        collectNodesById(node.children, targetMap);
      }
    }
    return targetMap;
  }

  function mergeHiddenBranchesById(visibleData, originalData) {
    const originalById = collectNodesById(originalData.nodes || []);

    function mergeNode(visibleNode) {
      const mergedChildren = (visibleNode.children || []).map((child) => mergeNode(child));
      const visibleChildIds = new Set(mergedChildren.map((child) => child.id));
      const originalNode = originalById.get(visibleNode.id);
      const hiddenChildren =
        originalNode && Array.isArray(originalNode.children)
          ? originalNode.children.filter((child) => child.hidden && !visibleChildIds.has(child.id))
          : [];
      // Preserve ALL fields from visibleNode — only replace children.
      return {
        ...visibleNode,
        children: [...mergedChildren, ...cloneJson(hiddenChildren)]
      };
    }

    return {
      nodes: (visibleData.nodes || []).map((node) => mergeNode(node)),
      viewScale: visibleData.viewScale,
      viewOffsetX: visibleData.viewOffsetX,
      viewOffsetY: visibleData.viewOffsetY
    };
  }

  // ── state.js ───────────────────────────────────────────────────────────────

  const BRANCH_THEMES = {
    Calm: {
      nodeFills: ["#eef2ff", "#e0f2fe", "#dcfce7", "#fef3c7", "#ffe4e6", "#ede9fe"],
      nodeBorders: ["#4f46e5", "#0284c7", "#16a34a", "#d97706", "#e11d48", "#7c3aed"],
      nodeTexts: ["#312e81", "#0c4a6e", "#14532d", "#7c2d12", "#881337", "#4c1d95"],
      linkColors: ["#6366f1", "#0284c7", "#16a34a", "#d97706", "#e11d48", "#7c3aed"]
    },
    Vivid: {
      nodeFills: ["#dbeafe", "#cffafe", "#d9f99d", "#fed7aa", "#fecdd3", "#ddd6fe"],
      nodeBorders: ["#2563eb", "#0e7490", "#65a30d", "#ea580c", "#e11d48", "#7c3aed"],
      nodeTexts: ["#1e3a8a", "#164e63", "#365314", "#7c2d12", "#9f1239", "#5b21b6"],
      linkColors: ["#2563eb", "#06b6d4", "#65a30d", "#f97316", "#f43f5e", "#8b5cf6"]
    },
    Minimal: {
      nodeFills: ["#f8fafc", "#f1f5f9", "#e2e8f0", "#f1f5f9", "#f8fafc", "#e2e8f0"],
      nodeBorders: ["#334155", "#475569", "#64748b", "#475569", "#334155", "#64748b"],
      nodeTexts: ["#0f172a", "#0f172a", "#0f172a", "#0f172a", "#0f172a", "#0f172a"],
      linkColors: ["#334155", "#475569", "#64748b", "#475569", "#334155", "#64748b"]
    }
  };

  function getBranchTheme(state) {
    return BRANCH_THEMES[state.branchTheme] || BRANCH_THEMES.Calm;
  }

  function createAppState() {
    const canvas = document.getElementById("mindmap");
    const ctx = canvas.getContext("2d");
    return {
      canvas,
      ctx,
      renameInput: document.getElementById("renameInput"),
      reorderUp: document.getElementById("reorderUp"),
      reorderDown: document.getElementById("reorderDown"),
      statusMessage: document.getElementById("statusMessage"),
      loadingIndicator: document.getElementById("loadingIndicator"),
      loadingText: document.getElementById("loadingText"),
      toolbar: document.getElementById("toolbar"),
      toolbarToggle: document.getElementById("toolbarToggle"),
      saveBtn: document.getElementById("saveBtn"),
      addBtn: document.getElementById("addBtn"),
      deleteBtn: document.getElementById("deleteBtn"),
      centerBtn: document.getElementById("centerBtn"),
      undoBtn: document.getElementById("undoBtn"),
      clearBtn: document.getElementById("clearBtn"),
      collapseBtn: document.getElementById("collapseBtn"),
      focusBtn: document.getElementById("focusBtn"),
      layoutBtn: document.getElementById("layoutBtn"),
      pinBtn: document.getElementById("pinBtn"),
      themeBtn: document.getElementById("themeBtn"),

      originalJsonData: null,
      nodes: [],
      links: [],
      selectedNode: null,
      draggingNode: null,
      ghostX: 0,
      ghostY: 0,
      offsetX: 0,
      offsetY: 0,
      isDragging: false,
      showGhostNode: false,
      debugShowZones: false,
      nodeZones: [],

      viewOffsetX: 0,
      viewOffsetY: 0,
      viewScale: 1,
      isPanning: false,
      panStartX: 0,
      panStartY: 0,

      lastTouchDist: null,
      lastTapTime: 0,
      lastTapNode: null,

      potentialParent: null,
      insertPosition: -1,

      history: [],
      maxHistorySteps: 20,

      currentGistId: null,
      hasUnsavedChanges: false,
      centerButtonClicks: [],

      animationFrameRequested: false,
      nextNodeId: 1,

      layoutMode: "horizontal",
      focusNodeId: null,
      visibleNodeIds: new Set(),
      visibleLinkKeys: new Set(),
      lastDragEndAt: 0,
      lastPointerDownNodeId: null,

      branchTheme: "Calm",
      layoutTransitionActive: false,
      searchMatchIds: new Set(),

      savePartBtn: document.getElementById("savePartBtn"),
      pushPartBtn: document.getElementById("pushPartBtn"),
      partsBtn: document.getElementById("partsBtn"),
      pinRefBtn: document.getElementById("pinRefBtn"),
      tagBtn: document.getElementById("tagBtn"),
      attachBtn: document.getElementById("attachBtn"),
      loadBtn: document.getElementById("loadBtn"),
      toolbarMinBtn: document.getElementById("toolbarMinBtn"),
      toolbarRevealBtn: document.getElementById("toolbarRevealBtn")
    };
  }

  function setCanvasSize(state) {
    state.canvas.width = window.innerWidth;
    state.canvas.height = window.innerHeight;
  }

  function createNode(state, text, explicitId = null) {
    const resolvedId = explicitId ?? state.nextNodeId;
    state.nextNodeId = Math.max(state.nextNodeId, resolvedId + 1);

    const node = {
      id: resolvedId,
      text,
      numbering: "",
      x: 0,
      y: 0,
      renderX: 0,
      renderY: 0,
      height: 40,
      width: 100,
      parent: null,
      children: [],
      collapsed: false,
      pinned: false,
      tags: [],
      attachments: [],
      instanceState: "live",
      pinnedSnapshot: null,
      calculateWidth() {
        // Image mode: use the first loaded image's scaled width.
        const imgInfo = getNodeFirstLoadedImage(this);
        if (imgInfo) {
          const { img } = imgInfo;
          const scale = Math.min(IMG_NODE_MAX_W / img.naturalWidth, IMG_NODE_MAX_H / img.naturalHeight, 1);
          return Math.round(img.naturalWidth * scale);
        }
        // If an image attachment exists but hasn't loaded yet, reserve space.
        if (this.attachments && this.attachments.some((a) => a.type && a.type.startsWith("image/"))) {
          return IMG_NODE_MAX_W;
        }
        state.ctx.font = "600 14px Manrope";
        const label = this.numbering ? `${this.numbering} ${this.text}` : this.text;
        return Math.max(100, state.ctx.measureText(label).width + 20);
      },
      draw(isGhost = false) {
        // ── Image-mode: render the first image attachment as the node itself ──
        const imgInfo = getNodeFirstLoadedImage(this);
        if (imgInfo) {
          const { img } = imgInfo;
          const scale = Math.min(IMG_NODE_MAX_W / img.naturalWidth, IMG_NODE_MAX_H / img.naturalHeight, 1);
          const iw = Math.round(img.naturalWidth * scale);
          const ih = Math.round(img.naturalHeight * scale);
          this.width = iw;
          this.height = ih;
          const x = isGhost ? state.ghostX : (Number.isFinite(this.renderX) ? this.renderX : this.x);
          const y = isGhost ? state.ghostY : (Number.isFinite(this.renderY) ? this.renderY : this.y);
          const RADIUS = 10;
          const isSelected = this === state.selectedNode && !isGhost;
          state.ctx.globalAlpha = isGhost ? 0.4 : 1;
          // Draw image clipped to rounded rect
          state.ctx.save();
          drawRoundedRectPath(state.ctx, x, y, iw, ih, RADIUS);
          state.ctx.clip();
          state.ctx.drawImage(img, x, y, iw, ih);
          state.ctx.restore();
          // Border / selection ring
          state.ctx.save();
          if (isSelected) {
            state.ctx.strokeStyle = "#2563eb";
            state.ctx.lineWidth = 2.5;
            state.ctx.shadowColor = "rgba(37,99,235,0.4)";
            state.ctx.shadowBlur = 12;
          } else {
            state.ctx.strokeStyle = "rgba(15,23,42,0.18)";
            state.ctx.lineWidth = 1.5;
          }
          drawRoundedRectPath(state.ctx, x, y, iw, ih, RADIUS);
          state.ctx.stroke();
          state.ctx.restore();
          state.ctx.globalAlpha = 1;
          return;
        }

        const theme = getBranchTheme(state);
        let depth = 0;
        let current = this.parent;
        while (current) {
          depth += 1;
          current = current.parent;
        }
        const paletteIndex = depth % theme.nodeFills.length;
        const palette = {
          fill: theme.nodeFills[paletteIndex],
          border: theme.nodeBorders[paletteIndex],
          text: theme.nodeTexts[paletteIndex]
        };
        this.width = this.calculateWidth();
        const label = this.numbering ? `${this.numbering} ${this.text}` : this.text;

        if (!Number.isFinite(this.renderX)) this.renderX = this.x;
        if (!Number.isFinite(this.renderY)) this.renderY = this.y;

        state.ctx.globalAlpha = isGhost ? 0.4 : 1;
        const isSelected = this === state.selectedNode && !isGhost;
        state.ctx.fillStyle = isSelected ? "#2563eb" : palette.fill;
        state.ctx.strokeStyle = isSelected ? "#1d4ed8" : palette.border;
        state.ctx.lineWidth = isSelected ? 2.2 : this.collapsed ? 2 : 1.6;
        const radius = 10;
        const x = isGhost ? state.ghostX : this.renderX;
        const y = isGhost ? state.ghostY : this.renderY;

        state.ctx.beginPath();
        state.ctx.moveTo(x + radius, y);
        state.ctx.lineTo(x + this.width - radius, y);
        state.ctx.quadraticCurveTo(x + this.width, y, x + this.width, y + radius);
        state.ctx.lineTo(x + this.width, y + this.height - radius);
        state.ctx.quadraticCurveTo(x + this.width, y + this.height, x + this.width - radius, y + this.height);
        state.ctx.lineTo(x + radius, y + this.height);
        state.ctx.quadraticCurveTo(x, y + this.height, x, y + this.height - radius);
        state.ctx.lineTo(x, y + radius);
        state.ctx.quadraticCurveTo(x, y, x + radius, y);
        state.ctx.closePath();

        state.ctx.shadowColor = isSelected ? "rgba(37, 99, 235, 0.38)" : "rgba(15, 23, 42, 0.08)";
        state.ctx.shadowBlur = isSelected ? 12 : 5;
        state.ctx.shadowOffsetY = isSelected ? 3 : 2;
        state.ctx.fill();
        state.ctx.shadowColor = "transparent";
        state.ctx.stroke();

        state.ctx.fillStyle = isSelected ? "#ffffff" : palette.text;
        state.ctx.font = "600 14px Manrope";
        state.ctx.textAlign = "center";
        state.ctx.textBaseline = "middle";
        state.ctx.fillText(label, x + this.width / 2, y + this.height / 2);

        if (this.pinned && !isGhost) {
          state.ctx.fillStyle = "#0f766e";
          state.ctx.beginPath();
          state.ctx.arc(x + 10, y + 10, 4, 0, Math.PI * 2);
          state.ctx.fill();
        }
        state.ctx.globalAlpha = 1;
      },
      isInside(mx, my) {
        const hitX = Number.isFinite(this.renderX) ? this.renderX : this.x;
        const hitY = Number.isFinite(this.renderY) ? this.renderY : this.y;
        return mx >= hitX && mx <= hitX + this.width && my >= hitY && my <= hitY + this.height;
      }
    };
    node.width = node.calculateWidth();
    node.renderX = node.x;
    node.renderY = node.y;
    return node;
  }

  function toCanvasCoords(state, x, y) {
    return {
      x: (x - state.viewOffsetX) / state.viewScale,
      y: (y - state.viewOffsetY) / state.viewScale
    };
  }

  function showStatus(state, message, duration = 3000) {
    state.statusMessage.textContent = message;
    state.statusMessage.classList.add("visible");
    setTimeout(() => {
      state.statusMessage.classList.remove("visible");
    }, duration);
  }

  function showLoading(state, text) {
    state.loadingText.textContent = text || "Loading...";
    state.loadingIndicator.style.display = "block";
  }

  function hideLoading(state) {
    state.loadingIndicator.style.display = "none";
  }

  function updateUndoButton(state) {
    state.undoBtn.disabled = state.history.length <= 1;
  }

  function updateDeleteButton(state) {
    const hasSelection = !!state.selectedNode;
    state.deleteBtn.disabled = !hasSelection;
    state.focusBtn.disabled = !hasSelection;
    state.pinBtn.disabled = !hasSelection;
    state.collapseBtn.disabled = !hasSelection || state.selectedNode.children.length === 0;
    updatePartButtons(state);
  }

  function updatePartButtons(state) {
    const node = state.selectedNode;
    state.savePartBtn.disabled = !node || !!node.resolvedFromPart;
    state.pushPartBtn.disabled = !node || !node.isGlobalPartSource;
    if (state.pinRefBtn) {
      state.pinRefBtn.disabled = !node || !node.linkedPartId || !!node.resolvedFromPart;
      const isPinned = node && node.instanceState === "pinned";
      state.pinRefBtn.classList.toggle("pinned-active", !!isPinned);
      const lbl = state.pinRefBtn.querySelector(".button-label");
      if (lbl) lbl.textContent = isPinned ? "Unpin" : "Pin Ref";
    }
    if (state.tagBtn) state.tagBtn.disabled = !node;
    if (state.attachBtn) state.attachBtn.disabled = !node;
  }

  function setUnsavedChanges(state, value) {
    state.hasUnsavedChanges = value;
    state.saveBtn.classList.toggle("highlight", state.hasUnsavedChanges);
  }

  function findNodeAt(state, mx, my) {
    for (const node of state.nodes) {
      if (node.isInside(mx, my)) return node;
    }
    return null;
  }

  // ── layout.js ──────────────────────────────────────────────────────────────

  function getRootNode(state) {
    return state.nodes.find((n) => !n.parent) || null;
  }

  function getNodeById(state, nodeId) {
    return state.nodes.find((node) => node.id === nodeId) || null;
  }

  function getVisibleChildren(node) {
    return node.collapsed ? [] : node.children;
  }

  function isDescendantOrSelf(node, ancestor) {
    if (!node || !ancestor) return false;
    let current = node;
    while (current) {
      if (current === ancestor) return true;
      current = current.parent;
    }
    return false;
  }

  function traverseVisible(root, visit) {
    if (!root) return;
    visit(root);
    for (const child of getVisibleChildren(root)) {
      traverseVisible(child, visit);
    }
  }

  function countVisibleLeaves(node) {
    const visibleChildren = getVisibleChildren(node);
    if (visibleChildren.length === 0) return 1;
    return visibleChildren.map(countVisibleLeaves).reduce((a, b) => a + b, 0);
  }

  function collectVisibleNodes(state) {
    const root = getRootNode(state);
    const nodes = [];
    traverseVisible(root, (node) => nodes.push(node));
    return nodes;
  }

  function collectVisibleLinks(state) {
    const links = [];
    const root = getRootNode(state);
    traverseVisible(root, (node) => {
      if (node.collapsed) return;
      for (const child of node.children) {
        links.push({ from: node, to: child });
      }
    });
    return links;
  }

  function rebuildVisibilityCaches(state) {
    const visibleNodes = collectVisibleNodes(state);
    const visibleLinks = collectVisibleLinks(state);
    state.visibleNodeIds = new Set(visibleNodes.map((node) => node.id));
    state.visibleLinkKeys = new Set(visibleLinks.map((link) => `${link.from.id}->${link.to.id}`));
    return { visibleNodes, visibleLinks };
  }

  function layoutHorizontal(state, root, { spacingY, horizontalPadding, baseX }) {
    for (const node of state.nodes) {
      node.width = node.calculateWidth();
    }
    const canvasCenterY = state.canvas.height / 2;
    const visibleLeafCount = countVisibleLeaves(root);
    const yRef = { value: canvasCenterY - (visibleLeafCount * spacingY) / 2 };

    function layoutNode(node, depth = 0) {
      if (!node.pinned) {
        if (node.parent) {
          node.x = node.parent.x + node.parent.width + horizontalPadding + depth * 2;
        } else {
          node.x = baseX;
        }
      }
      const visibleChildren = getVisibleChildren(node);
      if (visibleChildren.length === 0) {
        if (!node.pinned) node.y = yRef.value;
        yRef.value += node.height + spacingY;
        return node.y;
      }
      const childYs = visibleChildren.map((child) => layoutNode(child, depth + 1));
      const avgY = childYs.reduce((a, b) => a + b, 0) / childYs.length;
      if (!node.pinned) node.y = avgY;
      return node.y;
    }
    layoutNode(root);
  }

  function layoutRadial(state, root) {
    for (const node of state.nodes) {
      node.width = node.calculateWidth();
    }
    const centerX = state.canvas.width * 0.45;
    const centerY = state.canvas.height * 0.5;
    const radiusStep = 120;

    function assignPolar(node, startAngle, endAngle, depth) {
      const angle = (startAngle + endAngle) / 2;
      const radius = depth * radiusStep;
      if (!node.pinned) {
        if (depth === 0) {
          node.x = centerX;
          node.y = centerY;
        } else {
          node.x = centerX + Math.cos(angle) * radius;
          node.y = centerY + Math.sin(angle) * radius;
        }
      }
      const visibleChildren = getVisibleChildren(node);
      if (visibleChildren.length === 0) return;
      const totalLeaves = visibleChildren.map((child) => countVisibleLeaves(child)).reduce((a, b) => a + b, 0);
      let cursor = startAngle;
      for (const child of visibleChildren) {
        const childLeaves = countVisibleLeaves(child);
        const span = ((endAngle - startAngle) * childLeaves) / totalLeaves;
        assignPolar(child, cursor, cursor + span, depth + 1);
        cursor += span;
      }
    }
    assignPolar(root, -Math.PI * 0.85, Math.PI * 0.85, 0);
  }

  function runLayoutForMode(state, root) {
    if (state.layoutMode === "radial") {
      layoutRadial(state, root);
      return;
    }
    if (state.layoutMode === "compact") {
      layoutHorizontal(state, root, { spacingY: 36, horizontalPadding: 28, baseX: 90 });
      return;
    }
    layoutHorizontal(state, root, { spacingY: 60, horizontalPadding: 40, baseX: 100 });
  }

  function autoNumberNodes(state) {
    const root = getRootNode(state);
    if (!root) return;
    root.numbering = "";
    function assignNumbers(node, prefix = "") {
      node.children.forEach((child, index) => {
        const number = prefix ? `${prefix}.${index + 1}` : `${index + 1}`;
        child.numbering = `${number}.`;
        assignNumbers(child, number);
      });
    }
    assignNumbers(root);
  }

  function autoLayout(state) {
    resolveLinkedNodes(state);
    const root = getRootNode(state);
    if (!root) return;
    runLayoutForMode(state, root);
    autoNumberNodes(state);
    rebuildVisibilityCaches(state);
  }

  function calculateInsertionZones(state) {
    rebuildVisibilityCaches(state);
    state.nodeZones = [];
    const childrenByParent = new Map();

    state.nodes.forEach((node) => {
      if (!state.visibleNodeIds.has(node.id)) return;
      if (node.parent) {
        if (node.parent.collapsed) return;
        if (!childrenByParent.has(node.parent)) childrenByParent.set(node.parent, []);
        childrenByParent.get(node.parent).push(node);
      }
    });

    childrenByParent.forEach((children, parent) => {
      const sortedChildren = [...children].sort((a, b) => a.y - b.y);
      const standardZoneHeight = 30;

      sortedChildren.forEach((child, index) => {
        const isLastChild = index === sortedChildren.length - 1;
        const isFirstChild = index === 0;
        const zoneWidth = child.x - (parent.x + parent.width) + child.width;

        state.nodeZones.push({
          type: "before",
          parent,
          targetNode: child,
          actualIndex: parent.children.indexOf(child),
          x: parent.x + parent.width,
          y: child.y - standardZoneHeight,
          width: zoneWidth,
          height: standardZoneHeight,
          color: "rgba(255, 0, 0, 0.2)"
        });

        if (!isFirstChild) {
          const prevChild = sortedChildren[index - 1];
          const gapStart = prevChild.y + prevChild.height + standardZoneHeight;
          const gapEnd = child.y - standardZoneHeight;
          if (gapEnd > gapStart) {
            state.nodeZones.push({
              type: "extended-before",
              parent,
              targetNode: child,
              actualIndex: parent.children.indexOf(child),
              x: parent.x + parent.width,
              y: gapStart,
              width: zoneWidth,
              height: gapEnd - gapStart,
              color: "rgba(255, 0, 0, 0.2)"
            });
          }
        }

        if (isLastChild) {
          state.nodeZones.push({
            type: "after",
            parent,
            targetNode: child,
            actualIndex: parent.children.length,
            x: parent.x + parent.width,
            y: child.y + child.height,
            width: zoneWidth,
            height: standardZoneHeight,
            color: "rgba(0, 255, 0, 0.2)"
          });
        }
      });
    });

    state.nodes.forEach((node) => {
      if (!state.visibleNodeIds.has(node.id)) return;
      if (node.children.length === 0 || node.collapsed) {
        state.nodeZones.push({
          type: "child",
          parent: node,
          targetNode: null,
          actualIndex: 0,
          x: node.x + node.width,
          y: node.y,
          width: node.width,
          height: node.height,
          color: "rgba(255, 255, 0, 0.15)"
        });
      }
    });
  }

  function getVisibleNodes(state) {
    return collectVisibleNodes(state);
  }

  function getVisibleLinks(state) {
    return collectVisibleLinks(state);
  }

  function getFocusNode(state) {
    return state.focusNodeId === null ? null : getNodeById(state, state.focusNodeId);
  }

  function isNodeDimmedByFocus(state, node) {
    const focusNode = getFocusNode(state);
    if (!focusNode) return false;
    return !isDescendantOrSelf(node, focusNode);
  }

  function isLinkDimmedByFocus(state, fromNode, toNode) {
    const focusNode = getFocusNode(state);
    if (!focusNode) return false;
    return !(isDescendantOrSelf(fromNode, focusNode) && isDescendantOrSelf(toNode, focusNode));
  }

  function countHiddenDescendants(node) {
    let total = 0;
    function walk(current) {
      for (const child of current.children) {
        total += 1;
        walk(child);
      }
    }
    walk(node);
    return total;
  }

  function centerMindmap(state, requestDrawFn) {
    if (state.nodes.length === 0) return;
    const rootNode = getRootNode(state);
    if (!rootNode) return;
    const focusNode = getFocusNode(state);
    const anchorNode = focusNode || rootNode;
    const visibleNodes = collectVisibleNodes(state);
    let minY = Infinity;
    let maxY = -Infinity;
    for (const node of visibleNodes) {
      minY = Math.min(minY, node.y);
      maxY = Math.max(maxY, node.y + node.height);
    }
    const mindmapCenterY = (minY + maxY) / 2;
    const canvasCenterY = state.canvas.height / 2;
    const leftPadding = state.canvas.width * 0.15;
    state.viewOffsetX = leftPadding - anchorNode.x * state.viewScale;
    state.viewOffsetY = canvasCenterY - mindmapCenterY * state.viewScale;
    requestDrawFn();
    const now = Date.now();
    state.centerButtonClicks.push(now);
    state.centerButtonClicks = state.centerButtonClicks.filter((timestamp) => now - timestamp < 3000);
    if (state.centerButtonClicks.length >= 5) {
      state.debugShowZones = !state.debugShowZones;
      state.centerButtonClicks = [];
      showStatus(state, state.debugShowZones ? "Debug zones enabled" : "Debug zones disabled");
      requestDrawFn();
    }
  }

  // ── rendering.js ───────────────────────────────────────────────────────────

  function drawRoundedRectPath(ctx, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + width - r, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + r);
    ctx.lineTo(x + width, y + height - r);
    ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
    ctx.lineTo(x + r, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  function getNodeRenderPosition(node) {
    return {
      x: Number.isFinite(node.renderX) ? node.renderX : node.x,
      y: Number.isFinite(node.renderY) ? node.renderY : node.y
    };
  }

  function updateLayoutTransition(state) {
    let stillMoving = false;
    for (const node of state.nodes) {
      if (!Number.isFinite(node.renderX)) node.renderX = node.x;
      if (!Number.isFinite(node.renderY)) node.renderY = node.y;
      if (!state.layoutTransitionActive) {
        node.renderX = node.x;
        node.renderY = node.y;
        continue;
      }
      const dx = node.x - node.renderX;
      const dy = node.y - node.renderY;
      if (Math.abs(dx) < 0.35 && Math.abs(dy) < 0.35) {
        node.renderX = node.x;
        node.renderY = node.y;
        continue;
      }
      node.renderX += dx * 0.22;
      node.renderY += dy * 0.22;
      stillMoving = true;
    }
    if (state.layoutTransitionActive && !stillMoving) {
      state.layoutTransitionActive = false;
    }
    return stillMoving;
  }

  function drawLine(state, from, to, dimmed = false) {
    const fromPos = getNodeRenderPosition(from);
    const toPos = getNodeRenderPosition(to);
    const x1 = fromPos.x + from.width;
    const y1 = fromPos.y + from.height / 2;
    const x2 = toPos.x;
    const y2 = toPos.y + to.height / 2;
    const cp1x = x1 + 40;
    const cp2x = x2 - 40;
    const fromDepth = from.numbering ? from.numbering.split(".").filter(Boolean).length : 0;
    const theme = getBranchTheme(state);
    state.ctx.strokeStyle = dimmed
      ? "rgba(148, 163, 184, 0.2)"
      : theme.linkColors[fromDepth % theme.linkColors.length];
    state.ctx.lineWidth = dimmed ? 1 : 2.3;
    state.ctx.beginPath();
    state.ctx.moveTo(x1, y1);
    state.ctx.bezierCurveTo(cp1x, y1, cp2x, y2, x2, y2);
    state.ctx.stroke();
  }

  function drawNodeSummary(state, node) {
    if (node.children.length === 0 || !node.collapsed) return;
    const nodePos = getNodeRenderPosition(node);
    const previewItems = node.children.slice(0, 2).map((child) => child.text);
    const hiddenDescendants = countHiddenDescendants(node);
    const moreCount = Math.max(hiddenDescendants - previewItems.length, 0);
    const previewText = `${previewItems.join(", ")}${moreCount > 0 ? ` +${moreCount}` : ""}`;
    state.ctx.fillStyle = "rgba(30, 41, 59, 0.84)";
    state.ctx.font = "600 11px Manrope";
    state.ctx.textAlign = "left";
    state.ctx.textBaseline = "middle";
    state.ctx.fillText(previewText, nodePos.x + node.width + 10, nodePos.y + node.height / 2);
  }

  function drawPinnedMarker(state, node) {
    if (!node.pinned) return;
    state.ctx.fillStyle = "#0f766e";
    state.ctx.font = "700 12px Manrope";
    state.ctx.textAlign = "left";
    state.ctx.textBaseline = "top";
    const nodePos = getNodeRenderPosition(node);
    state.ctx.fillText("P", nodePos.x + 6, nodePos.y + 4);
  }

  // Cache for decoded HTMLImageElement objects keyed by attachment id.
  const _imgCache = new Map();

  // ── IndexedDB store for attachment data (bypasses ~5 MB localStorage quota) ──
  const _idb = (() => {
    const DB_NAME = "mindmap_attach_v1";
    const STORE = "data";
    let _dbPromise = null;
    function open() {
      if (_dbPromise) return _dbPromise;
      _dbPromise = new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, 1);
        req.onupgradeneeded = (e) => {
          const db = e.target.result;
          if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
        };
        req.onsuccess = (e) => resolve(e.target.result);
        req.onerror = () => { _dbPromise = null; reject(req.error); };
      });
      return _dbPromise;
    }
    return {
      put(id, data) {
        open().then((db) => {
          const tx = db.transaction(STORE, "readwrite");
          tx.objectStore(STORE).put({ id, data });
        }).catch(() => {});
      },
      remove(id) {
        open().then((db) => {
          const tx = db.transaction(STORE, "readwrite");
          tx.objectStore(STORE).delete(id);
        }).catch(() => {});
      },
      getAll() {
        return open().then((db) => new Promise((resolve, reject) => {
          const tx = db.transaction(STORE, "readonly");
          const req = tx.objectStore(STORE).getAll();
          req.onsuccess = () => {
            const map = new Map();
            for (const entry of req.result) map.set(entry.id, entry.data);
            resolve(map);
          };
          req.onerror = () => reject(req.error);
        })).catch(() => new Map());
      }
    };
  })();

  // ── Attachment data persistence ─────────────────────────────────────────
  // Primary: per-key localStorage (synchronous, survives refresh instantly).
  // Fallback: IndexedDB (async, for files too large for localStorage quota).

  function _attachKey(id) { return "mindmap.att." + id; }

  function _persistAttach(id, data) {
    // Try localStorage first — synchronous and reliable.
    try {
      if (canUseLocalStorage()) {
        window.localStorage.setItem(_attachKey(id), data);
        return;
      }
    } catch { /* QuotaExceededError — fall through to IDB */ }
    _idb.put(id, data);
  }

  function _dropAttach(id) {
    try { if (canUseLocalStorage()) window.localStorage.removeItem(_attachKey(id)); } catch {}
    _idb.remove(id);
  }

  // Restore att.data for all stripped attachments after loading from autosave.
  // Synchronous for localStorage hits; also fires an async IDB sweep for any
  // large files that were stored there instead.
  function reinflateAttachments(state) {
    let changed = false;
    for (const node of state.nodes) {
      if (!node.attachments) continue;
      for (const att of node.attachments) {
        if (att.data) continue;
        let data = null;
        try { if (canUseLocalStorage()) data = window.localStorage.getItem(_attachKey(att.id)); } catch {}
        if (data) {
          _imgCache.delete(att.id);
          att.data = data;
          changed = true;
        }
      }
    }
    if (changed) { autoLayout(state); requestDraw(state); }
    // Async IDB sweep for anything still missing (files that exceeded localStorage quota).
    _idb.getAll().then((dataMap) => {
      if (dataMap.size === 0) return;
      let idbChanged = false;
      for (const node of state.nodes) {
        if (!node.attachments) continue;
        for (const att of node.attachments) {
          if (!att.data && dataMap.has(att.id)) {
            _imgCache.delete(att.id);
            att.data = dataMap.get(att.id);
            idbChanged = true;
          }
        }
      }
      if (idbChanged) { autoLayout(state); requestDraw(state); }
    });
  }

  // Max dimensions for an image-mode node (image replaces the text box).
  const IMG_NODE_MAX_W = 160;
  const IMG_NODE_MAX_H = 120;

  // Returns {img, att} for the first image attachment that is fully loaded,
  // or null if none exists or the first image attachment hasn't loaded yet.
  function getNodeFirstLoadedImage(node) {
    if (!node.attachments || node.attachments.length === 0) return null;
    for (const att of node.attachments) {
      if (!att.type || !att.type.startsWith("image/")) continue;
      const img = _imgCache.get(att.id);
      if (img && img.complete && img.naturalWidth > 0) return { img, att };
      return null; // first image att found but not yet decoded
    }
    return null;
  }

  function _getCachedImg(state, att) {
    if (!att.data) return null;  // data not yet inflated — do not cache a broken image
    if (_imgCache.has(att.id)) return _imgCache.get(att.id);
    const img = new Image();
    img.onload = () => {
      // Update owning node's dimensions so layout uses image size.
      const ownerNode = state.nodes.find(
        (n) => n.attachments && n.attachments.some((a) => a.id === att.id)
      );
      if (ownerNode) {
        const scale = Math.min(
          IMG_NODE_MAX_W / img.naturalWidth,
          IMG_NODE_MAX_H / img.naturalHeight,
          1
        );
        ownerNode.width = Math.round(img.naturalWidth * scale);
        ownerNode.height = Math.round(img.naturalHeight * scale);
      }
      autoLayout(state);
      requestDraw(state);
    };
    img.src = att.data;
    _imgCache.set(att.id, img);
    return img;
  }

  function drawNodeAttachmentImages(state, node) {
    if (!node.attachments || node.attachments.length === 0) return;
    const imageAtts = node.attachments.filter((a) => a.type && a.type.startsWith("image/"));
    if (imageAtts.length === 0) return;

    const nodePos = getNodeRenderPosition(node);
    const THUMB_MAX_W = 90;
    const THUMB_MAX_H = 72;
    const GAP = 4;
    const TOP_MARGIN = 6;
    const RADIUS = 6;

    let offsetX = nodePos.x;
    const ty = nodePos.y + node.height + TOP_MARGIN;

    for (const att of imageAtts) {
      const img = _getCachedImg(state, att);
      if (!img.complete || img.naturalWidth === 0) continue;

      const scale = Math.min(THUMB_MAX_W / img.naturalWidth, THUMB_MAX_H / img.naturalHeight, 1);
      const tw = Math.round(img.naturalWidth * scale);
      const th = Math.round(img.naturalHeight * scale);

      // Clip to rounded rect and draw image
      state.ctx.save();
      drawRoundedRectPath(state.ctx, offsetX, ty, tw, th, RADIUS);
      state.ctx.clip();
      state.ctx.drawImage(img, offsetX, ty, tw, th);
      state.ctx.restore();

      // Thin border
      state.ctx.save();
      state.ctx.strokeStyle = "rgba(15, 23, 42, 0.15)";
      state.ctx.lineWidth = 1;
      drawRoundedRectPath(state.ctx, offsetX, ty, tw, th, RADIUS);
      state.ctx.stroke();
      state.ctx.restore();

      offsetX += tw + GAP;
    }
  }

  function updateReorderButtons(state) {
    if (!state.selectedNode || state.isDragging) {
      state.reorderUp.style.display = "none";
      state.reorderDown.style.display = "none";
      return;
    }
    const x =
      state.selectedNode.x * state.viewScale +
      state.viewOffsetX +
      state.selectedNode.width * state.viewScale +
      5;
    const y = state.selectedNode.y * state.viewScale + state.viewOffsetY;
    state.reorderUp.style.display = "block";
    state.reorderDown.style.display = "block";
    state.reorderUp.style.left = `${x}px`;
    state.reorderUp.style.top = `${y}px`;
    state.reorderDown.style.left = `${x}px`;
    state.reorderDown.style.top = `${y + 20}px`;
  }

  function drawAll(state) {
    const transitioning = updateLayoutTransition(state);
    state.ctx.setTransform(state.viewScale, 0, 0, state.viewScale, state.viewOffsetX, state.viewOffsetY);
    state.ctx.clearRect(
      -state.viewOffsetX / state.viewScale,
      -state.viewOffsetY / state.viewScale,
      state.canvas.width / state.viewScale,
      state.canvas.height / state.viewScale
    );

    calculateInsertionZones(state);

    if (state.debugShowZones) {
      for (const zone of state.nodeZones) {
        state.ctx.fillStyle = zone.color;
        state.ctx.fillRect(zone.x, zone.y, zone.width, zone.height);
        state.ctx.fillStyle = "black";
        state.ctx.font = "10px sans-serif";
        state.ctx.textAlign = "center";
        state.ctx.fillText(zone.type, zone.x + zone.width / 2, zone.y + zone.height / 2);
      }
    }

    const visibleLinks = getVisibleLinks(state);
    for (const link of visibleLinks) {
      const linkDimmed = isLinkDimmedByFocus(state, link.from, link.to);
      drawLine(state, link.from, link.to, linkDimmed);
    }

    const visibleNodes = getVisibleNodes(state);
    for (const node of visibleNodes) {
      const dimmed = isNodeDimmedByFocus(state, node);
      if (state.searchMatchIds.size > 0 && state.searchMatchIds.has(node.id)) {
        const pos = getNodeRenderPosition(node);
        const pad = 4;
        state.ctx.save();
        state.ctx.strokeStyle = "#f59e0b";
        state.ctx.lineWidth = 2.5;
        state.ctx.shadowColor = "rgba(245, 158, 11, 0.6)";
        state.ctx.shadowBlur = 10;
        drawRoundedRectPath(state.ctx, pos.x - pad, pos.y - pad, node.width + pad * 2, node.height + pad * 2, 14);
        state.ctx.stroke();
        state.ctx.restore();
      }
      if (dimmed) state.ctx.globalAlpha = 0.2;
      node.draw(false);
      state.ctx.globalAlpha = 1;
      if (!node.isGlobalPartSource && !node.linkedPartId) {
        drawNodeSummary(state, node);
      }
      drawPinnedMarker(state, node);

      // Global part visual indicators
      const gpos = getNodeRenderPosition(node);
      if (node.isGlobalPartSource || node.linkedPartId) {
        const isPinned = node.instanceState === "pinned";
        const color = node.isGlobalPartSource ? "#16a34a" : (isPinned ? "#d97706" : "#16a34a");
        const borderColor = isPinned ? "#d97706" : "#16a34a";
        if (node.linkedPartId) {
          state.ctx.save();
          state.ctx.strokeStyle = borderColor;
          state.ctx.lineWidth = 1.8;
          state.ctx.setLineDash([4, 3]);
          drawRoundedRectPath(state.ctx, gpos.x - 3, gpos.y - 3, node.width + 6, node.height + 6, 13);
          state.ctx.stroke();
          state.ctx.setLineDash([]);
          state.ctx.restore();
        } else {
          state.ctx.save();
          state.ctx.strokeStyle = color;
          state.ctx.lineWidth = 2;
          state.ctx.shadowColor = "rgba(22, 163, 74, 0.45)";
          state.ctx.shadowBlur = 8;
          drawRoundedRectPath(state.ctx, gpos.x - 3, gpos.y - 3, node.width + 6, node.height + 6, 13);
          state.ctx.stroke();
          state.ctx.restore();
        }
      }
      if (node.resolvedFromPart) {
        state.ctx.fillStyle = "rgba(22, 163, 74, 0.75)";
        state.ctx.beginPath();
        state.ctx.arc(gpos.x + node.width - 6, gpos.y + 6, 3.5, 0, Math.PI * 2);
        state.ctx.fill();
      }
      // Tag indicator: small amber dot at top-left if node has tags
      if (node.tags && node.tags.length > 0) {
        state.ctx.fillStyle = "#f59e0b";
        state.ctx.beginPath();
        state.ctx.arc(gpos.x + 7, gpos.y + 7, 3.5, 0, Math.PI * 2);
        state.ctx.fill();
      }
      // Attachment indicator: small purple dot at bottom-right if node has attachments
      if (node.attachments && node.attachments.length > 0) {
        state.ctx.fillStyle = "#7c3aed";
        state.ctx.beginPath();
        state.ctx.arc(gpos.x + node.width - 7, gpos.y + node.height - 7, 3.5, 0, Math.PI * 2);
        state.ctx.fill();
      }
      // Warm the image cache for image attachments (triggers async decode + layout update).
      if (node.attachments) {
        for (const att of node.attachments) {
          if (att.data && att.type && att.type.startsWith("image/")) _getCachedImg(state, att);
        }
      }
    }

    if (state.isDragging && state.draggingNode && state.showGhostNode) {
      state.ctx.globalAlpha = 0.5;
      state.draggingNode.draw(true);
      state.ctx.globalAlpha = 1;
      if (state.potentialParent) {
        state.ctx.strokeStyle = "#007bff";
        state.ctx.lineWidth = 2;
        state.ctx.setLineDash([5, 3]);
        const startX = state.potentialParent.x + state.potentialParent.width;
        const startY = state.potentialParent.y + state.potentialParent.height / 2;
        const endX = state.ghostX;
        const endY = state.ghostY + state.draggingNode.height / 2;
        const cp1x = startX + 40;
        const cp2x = endX - 40;
        state.ctx.beginPath();
        state.ctx.moveTo(startX, startY);
        state.ctx.bezierCurveTo(cp1x, startY, cp2x, endY, endX, endY);
        state.ctx.stroke();
        state.ctx.setLineDash([]);
      }
    }

    state.ctx.setTransform(1, 0, 0, 1, 0, 0);
    const tagText = `Layout: ${state.layoutMode}`;
    state.ctx.font = "700 12px Manrope";
    const tagWidth = state.ctx.measureText(tagText).width + 18;
    state.ctx.fillStyle = "rgba(255, 255, 255, 0.82)";
    state.ctx.strokeStyle = "rgba(99, 102, 241, 0.28)";
    state.ctx.lineWidth = 1;
    drawRoundedRectPath(state.ctx, 8, 8, tagWidth, 24, 12);
    state.ctx.fill();
    state.ctx.stroke();
    state.ctx.fillStyle = "rgba(31, 41, 55, 0.85)";
    state.ctx.textAlign = "left";
    state.ctx.textBaseline = "alphabetic";
    state.ctx.fillText(tagText, 17, 25);

    updateReorderButtons(state);
    return transitioning;
  }

  function requestDraw(state) {
    if (state.animationFrameRequested) return;
    state.animationFrameRequested = true;
    requestAnimationFrame(() => {
      const shouldContinue = drawAll(state);
      state.animationFrameRequested = false;
      if (shouldContinue) requestDraw(state);
    });
  }

  // ── persistence.js ─────────────────────────────────────────────────────────

  const AUTOSAVE_SCHEMA_VERSION = 1;
  const AUTOSAVE_STORAGE_KEY = "mindmap.autosave.v1";

  function canUseLocalStorage() {
    try {
      return typeof window !== "undefined" && !!window.localStorage;
    } catch {
      return false;
    }
  }

  function mindmapToJson(state, stripAttachData = false) {
    const root = state.nodes.find((n) => !n.parent);
    if (!root) return { nodes: [] };

    function buildNodeTree(node) {
      return {
        id: node.id,
        text: node.text,
        collapsed: !!node.collapsed,
        pinned: !!node.pinned,
        linkedPartId: node.linkedPartId || undefined,
        isGlobalPartSource: node.isGlobalPartSource || undefined,
        tags: (node.tags && node.tags.length > 0) ? node.tags : undefined,
        attachments: (node.attachments && node.attachments.length > 0)
          ? (stripAttachData
            ? node.attachments.map(({ id, type, name, size }) => ({ id, type, name, size }))
            : node.attachments)
          : undefined,
        instanceState: (node.instanceState && node.instanceState !== "live") ? node.instanceState : undefined,
        pinnedSnapshot: node.pinnedSnapshot || undefined,
        children: node.children
          .filter((c) => !c.resolvedFromPart)
          .map((child) => buildNodeTree(child))
      };
    }

    const visibleData = {
      nodes: [buildNodeTree(root)],
      layoutMode: state.layoutMode,
      branchTheme: state.branchTheme,
      viewScale: state.viewScale,
      viewOffsetX: state.viewOffsetX,
      viewOffsetY: state.viewOffsetY
    };

    if (state.originalJsonData && state.originalJsonData.nodes) {
      return mergeHiddenBranchesById(visibleData, state.originalJsonData);
    }
    return visibleData;
  }

  function buildAutosaveDocument(state) {
    return {
      version: AUTOSAVE_SCHEMA_VERSION,
      savedAt: Date.now(),
      gistId: state.currentGistId || null,
      mindmap: mindmapToJson(state, true)  // strip attachment data — stored separately in IndexedDB
    };
  }

  function writeAutosave(state) {
    if (!canUseLocalStorage()) return;
    try {
      const doc = buildAutosaveDocument(state);
      window.localStorage.setItem(AUTOSAVE_STORAGE_KEY, JSON.stringify(doc));
    } catch {
      // ignore
    }
  }

  function readAutosaveDocument() {
    if (!canUseLocalStorage()) return null;
    try {
      const raw = window.localStorage.getItem(AUTOSAVE_STORAGE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || parsed.version !== AUTOSAVE_SCHEMA_VERSION || !parsed.mindmap) return null;
      return parsed;
    } catch {
      return null;
    }
  }

  function saveToHistory(state) {
    const snapshotNodes = state.nodes
      .filter((node) => !node.resolvedFromPart)
      .map((node) => ({
      id: node.id,
      text: node.text,
      numbering: node.numbering,
      x: node.x,
      y: node.y,
      height: node.height,
      width: node.width,
      parentId: node.parent ? node.parent.id : null,
      childIds: node.children.filter((c) => !c.resolvedFromPart).map((child) => child.id),
      collapsed: !!node.collapsed,
      pinned: !!node.pinned,
      linkedPartId: node.linkedPartId || null,
      isGlobalPartSource: node.isGlobalPartSource || null,
      tags: node.tags || [],
      attachments: node.attachments || [],
      instanceState: node.instanceState || "live",
      pinnedSnapshot: node.pinnedSnapshot || null
    }));

    const snapshotLinks = state.links.map((link) => ({
      fromId: link.from.id,
      toId: link.to.id
    }));

    state.history.push({
      nodes: snapshotNodes,
      links: snapshotLinks,
      selectedNodeId: state.selectedNode ? state.selectedNode.id : null,
      focusNodeId: state.focusNodeId,
      layoutMode: state.layoutMode,
      branchTheme: state.branchTheme,
      viewOffsetX: state.viewOffsetX,
      viewOffsetY: state.viewOffsetY,
      viewScale: state.viewScale,
      nextNodeId: state.nextNodeId
    });

    if (state.history.length > state.maxHistorySteps) {
      state.history = state.history.slice(1);
    }

    updateUndoButton(state);
    setUnsavedChanges(state, true);
    writeAutosave(state);
  }

  function restoreFromHistory(state, snapshot) {
    const idToNode = new Map();
    for (const nodeSnapshot of snapshot.nodes) {
      const node = createNode(state, nodeSnapshot.text, nodeSnapshot.id);
      node.numbering = nodeSnapshot.numbering;
      node.x = nodeSnapshot.x;
      node.y = nodeSnapshot.y;
      node.height = nodeSnapshot.height;
      node.width = nodeSnapshot.width;
      node.parent = null;
      node.children = [];
      node.collapsed = !!nodeSnapshot.collapsed;
      node.pinned = !!nodeSnapshot.pinned;
      node.linkedPartId = nodeSnapshot.linkedPartId || null;
      node.isGlobalPartSource = nodeSnapshot.isGlobalPartSource || null;
      node.tags = nodeSnapshot.tags || [];
      node.attachments = nodeSnapshot.attachments || [];
      node.instanceState = nodeSnapshot.instanceState || "live";
      node.pinnedSnapshot = nodeSnapshot.pinnedSnapshot || null;
      idToNode.set(node.id, node);
    }
    for (const nodeSnapshot of snapshot.nodes) {
      const node = idToNode.get(nodeSnapshot.id);
      if (nodeSnapshot.parentId !== null) {
        node.parent = idToNode.get(nodeSnapshot.parentId) || null;
      }
      node.children = (nodeSnapshot.childIds || []).map((childId) => idToNode.get(childId)).filter(Boolean);
    }
    state.nodes = snapshot.nodes.map((nodeSnapshot) => idToNode.get(nodeSnapshot.id));
    state.links = snapshot.links
      .map((linkSnapshot) => ({
        from: idToNode.get(linkSnapshot.fromId),
        to: idToNode.get(linkSnapshot.toId)
      }))
      .filter((link) => link.from && link.to);
    state.selectedNode = snapshot.selectedNodeId !== null ? idToNode.get(snapshot.selectedNodeId) || null : null;
    state.focusNodeId = snapshot.focusNodeId ?? null;
    state.layoutMode = snapshot.layoutMode || "horizontal";
    state.branchTheme = snapshot.branchTheme || "Calm";
    state.viewOffsetX = snapshot.viewOffsetX;
    state.viewOffsetY = snapshot.viewOffsetY;
    state.viewScale = snapshot.viewScale;
    state.nextNodeId = Math.max(state.nextNodeId, snapshot.nextNodeId || 1);
    resolveLinkedNodes(state);
    requestDraw(state);
  }

  function undo(state) {
    if (state.history.length <= 1) return;
    state.history.pop();
    const previousSnapshot = state.history[state.history.length - 1];
    restoreFromHistory(state, previousSnapshot);
    updateUndoButton(state);
    updateDeleteButton(state);
    setUnsavedChanges(state, true);
  }

  function jsonToMindmap(state, jsonData) {
    state.nextNodeId = 1;
    const { normalized, nextId } = normalizeJsonWithStableIds(jsonData, state.nextNodeId);
    state.nextNodeId = nextId;
    state.originalJsonData = cloneJson(normalized);
    state.nodes = [];
    state.links = [];

    function createNodesFromJson(nodeData, parent = null) {
      if (nodeData.hidden) return null;
      const node = createNode(state, nodeData.text, nodeData.id);
      node.parent = parent;
      node.collapsed = !!nodeData.collapsed;
      node.pinned = !!nodeData.pinned;
      node.linkedPartId = nodeData.linkedPartId || null;
      node.isGlobalPartSource = nodeData.isGlobalPartSource || null;
      node.tags = nodeData.tags || [];
      node.attachments = nodeData.attachments || [];
      node.instanceState = nodeData.instanceState || "live";
      node.pinnedSnapshot = nodeData.pinnedSnapshot || null;
      state.nodes.push(node);
      if (parent) {
        parent.children.push(node);
        state.links.push({ from: parent, to: node });
      }
      const children = Array.isArray(nodeData.children) ? nodeData.children : [];
      children.forEach((childData) => createNodesFromJson(childData, node));
      return node;
    }

    (normalized.nodes || []).forEach((nodeData) => createNodesFromJson(nodeData));

    if (normalized.viewScale) state.viewScale = normalized.viewScale;
    if (normalized.layoutMode) state.layoutMode = normalized.layoutMode;
    if (normalized.branchTheme) state.branchTheme = normalized.branchTheme;
    if (normalized.viewOffsetX) state.viewOffsetX = normalized.viewOffsetX;
    if (normalized.viewOffsetY) state.viewOffsetY = normalized.viewOffsetY;

    autoLayout(state);
    requestDraw(state);
    setUnsavedChanges(state, false);
    saveToHistory(state);
    state.history = [state.history[0]];
    updateUndoButton(state);
    centerMindmap(state, () => requestDraw(state));
  }

  function recoverFromAutosave(state) {
    const autosaveDoc = readAutosaveDocument();
    if (!autosaveDoc) return false;
    jsonToMindmap(state, autosaveDoc.mindmap);
    state.currentGistId = autosaveDoc.gistId || null;
    if (!state.selectedNode && state.nodes.length > 0) {
      state.selectedNode = state.nodes.find((n) => !n.parent) || state.nodes[0];
    }
    updateDeleteButton(state);
    setUnsavedChanges(state, true);
    reinflateAttachments(state);  // sync localStorage read + async IDB sweep
    showStatus(state, "Recovered from local autosave");
    return true;
  }

  async function loadFromGist(state, gistId) {
    if (!gistId) return;
    state.currentGistId = gistId;
    showLoading(state, "Loading mindmap from GitHub...");
    try {
      const response = await fetch(`/api/loadGist?gistId=${gistId}`, {
        method: "GET",
        headers: { "Content-Type": "application/json" }
      });
      const responseText = await response.text();
      let data;
      try {
        data = JSON.parse(responseText);
      } catch {
        throw new Error(`Failed to parse response as JSON. First 100 chars: ${responseText.substring(0, 100)}...`);
      }
      if (!data.files || !data.files["mindmap.json"]) {
        throw new Error("No mindmap.json file found in this Gist");
      }
      const mindmapContent = data.files["mindmap.json"].content;
      const mindmapData = JSON.parse(mindmapContent);
      jsonToMindmap(state, mindmapData);
      showStatus(state, "Mindmap loaded successfully");
    } catch (error) {
      showStatus(state, `Error: ${error.message}`, 5000);
    } finally {
      hideLoading(state);
    }
  }

  function saveAsLocalFile(state) {
    if (state.nodes.length === 0) { showStatus(state, "Nothing to save"); return; }
    const mindmapData = mindmapToJson(state);
    const json = JSON.stringify(mindmapData, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "mindmap.json";
    a.click();
    URL.revokeObjectURL(url);
    setUnsavedChanges(state, false);
    showStatus(state, "Mindmap downloaded as mindmap.json");
  }

  function loadFromFile(state) {
    const input = document.getElementById("loadFileInput");
    if (!input) return;
    // Reset so the same file can be re-selected after a first load
    input.value = "";
    input.onchange = () => {
      const file = input.files && input.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        try {
          const json = JSON.parse(evt.target.result);
          jsonToMindmap(state, json);
          // Persist any attachment data that came with the file so page refreshes retain images.
          for (const node of state.nodes) {
            if (!node.attachments) continue;
            for (const att of node.attachments) {
              if (att.data) _persistAttach(att.id, att.data);
            }
          }
          reinflateAttachments(state);
          centerMindmap(state, () => requestDraw(state));
          showStatus(state, `Loaded: ${file.name}`);
        } catch {
          showStatus(state, "Failed to load: invalid JSON file", 4000);
        }
      };
      reader.readAsText(file);
    };
    input.click();
  }

  async function saveToGist(state) {
    if (!state.currentGistId) {
      saveAsLocalFile(state);
      return;
    }
    if (state.nodes.length === 0) {
      showStatus(state, "Nothing to save");
      return;
    }
    showLoading(state, "Saving mindmap to GitHub...");
    try {
      const mindmapData = mindmapToJson(state);
      const response = await fetch("/api/saveGist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          gistId: state.currentGistId,
          files: { "mindmap.json": { content: JSON.stringify(mindmapData, null, 2) } }
        })
      });
      if (!response.ok) {
        let errorMessage = response.statusText;
        try {
          const errorData = await response.json();
          errorMessage = errorData.error || errorMessage;
        } catch {
          const text = await response.text();
          errorMessage = text.includes("<!DOCTYPE html>")
            ? "Received HTML instead of JSON. API endpoint may not exist."
            : `${text.substring(0, 100)}...`;
        }
        throw new Error(`Failed to save Gist: ${errorMessage}`);
      }
      await response.json();
      setUnsavedChanges(state, false);
      showStatus(state, "Mindmap saved successfully");
    } catch (error) {
      showStatus(state, `Error: ${error.message}`, 5000);
    } finally {
      hideLoading(state);
    }
  }

  // ── input.js ───────────────────────────────────────────────────────────────

  function getCanvasRelativeCoords(state, clientX, clientY) {
    const rect = state.canvas.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    return { x, y, canvasCoords: toCanvasCoords(state, x, y) };
  }

  function getTouchDistance(e) {
    const dx = e.touches[0].clientX - e.touches[1].clientX;
    const dy = e.touches[0].clientY - e.touches[1].clientY;
    return Math.sqrt(dx * dx + dy * dy);
  }

  function beginInteraction(state, screenX, screenY, mx, my, options = {}) {
    const { allowDoubleTapRename = false } = options;
    state.isPanning = true;
    state.panStartX = screenX - state.viewOffsetX;
    state.panStartY = screenY - state.viewOffsetY;
    const hitNode = findNodeAt(state, mx, my);
    if (!hitNode) {
      state.lastPointerDownNodeId = null;
      return;
    }
    state.lastPointerDownNodeId = hitNode.id;
    const dragX = Number.isFinite(hitNode.renderX) ? hitNode.renderX : hitNode.x;
    const dragY = Number.isFinite(hitNode.renderY) ? hitNode.renderY : hitNode.y;
    state.offsetX = mx - dragX;
    state.offsetY = my - dragY;
    state.draggingNode = hitNode;
    state.ghostX = dragX;
    state.ghostY = dragY;
    state.isDragging = false;
    state.selectedNode = hitNode;
    updateDeleteButton(state);
    state.isPanning = false;
    if (!allowDoubleTapRename) return;
    const now = Date.now();
    if (state.lastTapNode === hitNode && now - state.lastTapTime < 400) {
      showRenameInput(state, hitNode);
    }
    state.lastTapNode = hitNode;
    state.lastTapTime = now;
  }

  function updatePan(state, screenX, screenY) {
    if (!state.isPanning) return;
    state.viewOffsetX = screenX - state.panStartX;
    state.viewOffsetY = screenY - state.panStartY;
    requestDraw(state);
  }

  function handlePointerMove(state, mx, my, touchPadding = 0) {
    state.insertPosition = -1;
    state.potentialParent = null;
    for (const zone of state.nodeZones) {
      if (zone.targetNode === state.draggingNode || zone.parent === state.draggingNode) continue;
      if (
        mx >= zone.x - touchPadding &&
        mx <= zone.x + zone.width + touchPadding &&
        my >= zone.y - touchPadding &&
        my <= zone.y + zone.height + touchPadding
      ) {
        state.potentialParent = zone.parent;
        if (zone.type === "before" || zone.type === "extended-before") {
          state.insertPosition = zone.actualIndex;
        } else if (zone.type === "after") {
          state.insertPosition = zone.actualIndex;
        } else if (zone.type === "child") {
          state.insertPosition = 0;
        }
        return;
      }
    }
    for (const node of state.nodes) {
      if (node !== state.draggingNode && node.isInside(mx, my)) {
        state.potentialParent = node;
        state.insertPosition = node.children.length;
        return;
      }
    }
  }

  function updateDrag(state, mx, my, touchPadding = 0) {
    if (!state.draggingNode) return;
    const dx = mx - state.ghostX;
    const dy = my - state.ghostY;
    if (!state.isDragging && (Math.abs(dx) > 3 || Math.abs(dy) > 3)) {
      state.isDragging = true;
      state.showGhostNode = true;
    }
    if (!state.isDragging) return;
    state.ghostX = mx - state.offsetX;
    state.ghostY = my - state.offsetY;
    handlePointerMove(state, mx, my, touchPadding);
    requestDraw(state);
  }

  function completeDrag(state) {
    const wasDragging = state.isDragging;
    if (!state.isDragging || !state.draggingNode) {
      state.potentialParent = null;
      state.insertPosition = -1;
      state.showGhostNode = false;
      state.draggingNode = null;
      state.isDragging = false;
      requestDraw(state);
      updateDeleteButton(state);
      return;
    }
    if (state.potentialParent) {
      let adjustedInsertPosition = state.insertPosition;
      if (state.draggingNode.parent === state.potentialParent) {
        const originalIndex = state.potentialParent.children.indexOf(state.draggingNode);
        if (originalIndex < adjustedInsertPosition) adjustedInsertPosition -= 1;
      }
      if (state.draggingNode.parent) {
        state.draggingNode.parent.children = state.draggingNode.parent.children.filter((c) => c !== state.draggingNode);
      }
      state.draggingNode.parent = state.potentialParent;
      if (adjustedInsertPosition >= 0 && adjustedInsertPosition <= state.potentialParent.children.length) {
        state.potentialParent.children.splice(adjustedInsertPosition, 0, state.draggingNode);
      } else {
        state.potentialParent.children.push(state.draggingNode);
      }
      state.links = state.links.filter((l) => l.to !== state.draggingNode);
      state.links.push({ from: state.potentialParent, to: state.draggingNode });
      autoLayout(state);
      saveToHistory(state);
    }
    state.potentialParent = null;
    state.insertPosition = -1;
    state.showGhostNode = false;
    state.draggingNode = null;
    state.isDragging = false;
    state.lastDragEndAt = wasDragging ? Date.now() : state.lastDragEndAt;
    requestDraw(state);
    updateDeleteButton(state);
  }

  function handlePinchZoom(state, e) {
    if (e.touches.length !== 2 || !state.lastTouchDist) return false;
    const newDist = getTouchDistance(e);
    const zoomAmount = newDist / state.lastTouchDist;
    const rect = state.canvas.getBoundingClientRect();
    const midX = (e.touches[0].clientX + e.touches[1].clientX) / 2 - rect.left;
    const midY = (e.touches[0].clientY + e.touches[1].clientY) / 2 - rect.top;
    const mouse = toCanvasCoords(state, midX, midY);
    const newScale = Math.min(Math.max(state.viewScale * zoomAmount, 0.1), 4);
    state.viewOffsetX -= mouse.x * newScale - mouse.x * state.viewScale;
    state.viewOffsetY -= mouse.y * newScale - mouse.y * state.viewScale;
    state.viewScale = newScale;
    state.lastTouchDist = newDist;
    requestDraw(state);
    return true;
  }

  function addNode(state) {
    if (state.nodes.length === 0) {
      const node = createNode(state, "New node");
      state.nodes.push(node);
      state.selectedNode = node;
      autoLayout(state);
      requestDraw(state);
      updateDeleteButton(state);
      saveToHistory(state);
      setTimeout(() => {
        node.width = node.calculateWidth();
        showRenameInput(state, node);
      }, 10);
      return;
    }
    if (!state.selectedNode) {
      const root = state.nodes.find((n) => !n.parent);
      if (root) {
        state.selectedNode = root;
        updateDeleteButton(state);
      } else {
        showStatus(state, "Click a node first to add a child");
        return;
      }
    }
    if (state.selectedNode.resolvedFromPart) {
      showStatus(state, "Linked children are read-only — edit the source node and Push to update.");
      return;
    }
    const node = createNode(state, "New node");
    if (state.selectedNode.collapsed) state.selectedNode.collapsed = false;
    node.parent = state.selectedNode;
    state.selectedNode.children.push(node);
    state.links.push({ from: state.selectedNode, to: node });
    state.nodes.push(node);
    state.selectedNode = node;
    autoLayout(state);
    requestDraw(state);
    updateDeleteButton(state);
    saveToHistory(state);
    showRenameInput(state, node);
  }

  function deleteNode(state) {
    if (!state.selectedNode) {
      showStatus(state, "Select a node first");
      return;
    }
    if (state.selectedNode.resolvedFromPart) {
      showStatus(state, "Linked children are read-only — edit the source node and Push to update.");
      return;
    }
    if (state.selectedNode.parent) {
      state.selectedNode.parent.children = state.selectedNode.parent.children.filter(
        (child) => child !== state.selectedNode
      );
    }
    function removeNodeAndDescendants(node) {
      for (const child of [...node.children]) removeNodeAndDescendants(child);
      state.links = state.links.filter((link) => link.from !== node && link.to !== node);
      const nodeIndex = state.nodes.indexOf(node);
      if (nodeIndex > -1) state.nodes.splice(nodeIndex, 1);
    }
    removeNodeAndDescendants(state.selectedNode);
    if (state.focusNodeId === state.selectedNode?.id) state.focusNodeId = null;
    state.selectedNode = null;
    autoLayout(state);
    requestDraw(state);
    updateDeleteButton(state);
    saveToHistory(state);
  }

  function toggleCollapseSelected(state) {
    if (!state.selectedNode) { showStatus(state, "Select a node first"); return; }
    if (state.selectedNode.children.length === 0) { showStatus(state, "Selected node has no children"); return; }
    state.selectedNode.collapsed = !state.selectedNode.collapsed;
    autoLayout(state);
    requestDraw(state);
    saveToHistory(state);
  }

  function togglePinSelected(state) {
    if (!state.selectedNode) { showStatus(state, "Select a node first"); return; }
    state.selectedNode.pinned = !state.selectedNode.pinned;
    autoLayout(state);
    requestDraw(state);
    saveToHistory(state);
  }

  function cycleLayoutMode(state) {
    const modes = ["horizontal", "radial", "compact"];
    const idx = modes.indexOf(state.layoutMode);
    state.layoutMode = modes[(idx + 1) % modes.length];
    state.layoutTransitionActive = true;
    autoLayout(state);
    centerMindmap(state, () => requestDraw(state));
    requestDraw(state);
    saveToHistory(state);
    showStatus(state, `Layout: ${state.layoutMode}`);
  }

  function cycleBranchTheme(state) {
    const themes = ["Calm", "Vivid", "Minimal"];
    const idx = themes.indexOf(state.branchTheme);
    state.branchTheme = themes[(idx + 1) % themes.length];
    requestDraw(state);
    saveToHistory(state);
    showStatus(state, `Theme: ${state.branchTheme}`);
  }

  function toggleFocusForNode(state, node) {
    if (!node) return;
    state.focusNodeId = state.focusNodeId === node.id ? null : node.id;
    centerMindmap(state, () => requestDraw(state));
    requestDraw(state);
    showStatus(state, state.focusNodeId ? "Focus mode enabled" : "Focus mode cleared");
  }

  function toggleFocusSelected(state) {
    if (!state.selectedNode) { showStatus(state, "Select a node first"); return; }
    toggleFocusForNode(state, state.selectedNode);
  }

  function clearNodes(state) {
    state.nodes = [];
    state.links = [];
    state.selectedNode = null;
    state.focusNodeId = null;
    requestDraw(state);
    updateDeleteButton(state);
    saveToHistory(state);
    showStatus(state, "Canvas cleared");
  }

  function moveNodeUp(state) {
    if (!state.selectedNode || !state.selectedNode.parent) return;
    const siblings = state.selectedNode.parent.children;
    const idx = siblings.indexOf(state.selectedNode);
    if (idx > 0) {
      [siblings[idx - 1], siblings[idx]] = [siblings[idx], siblings[idx - 1]];
      autoLayout(state);
      requestDraw(state);
      saveToHistory(state);
    }
  }

  function moveNodeDown(state) {
    if (!state.selectedNode || !state.selectedNode.parent) return;
    const siblings = state.selectedNode.parent.children;
    const idx = siblings.indexOf(state.selectedNode);
    if (idx < siblings.length - 1) {
      [siblings[idx], siblings[idx + 1]] = [siblings[idx + 1], siblings[idx]];
      autoLayout(state);
      requestDraw(state);
      saveToHistory(state);
    }
  }

  function showRenameInput(state, node) {
    if (node.resolvedFromPart) {
      showStatus(state, "Linked children are read-only — edit the source node and Push to update.");
      return;
    }
    const scale = state.viewScale;
    node.width = node.calculateWidth();
    const x = node.x * scale + state.viewOffsetX;
    const y = node.y * scale + state.viewOffsetY;
    state.renameInput.style.display = "block";
    state.renameInput.value = node.text;
    state.renameInput.style.left = `${x}px`;
    state.renameInput.style.top = `${y}px`;
    state.renameInput.style.width = `${node.width * scale}px`;
    state.renameInput.style.height = `${node.height * scale}px`;
    state.renameInput.style.fontSize = `${14 * scale}px`;
    state.renameInput.style.lineHeight = `${node.height * scale}px`;
    state.renameInput.style.borderRadius = `${10 * scale}px`;
    state.renameInput.style.paddingLeft = `${10 * scale}px`;
    state.renameInput.style.paddingRight = `${10 * scale}px`;
    setTimeout(() => {
      state.renameInput.focus();
      state.renameInput.select();
    }, 10);
    const originalText = node.text;
    state.renameInput.onblur = () => {
      const newText = state.renameInput.value.trim() || node.text;
      state.renameInput.style.display = "none";
      if (newText !== originalText) {
        node.text = newText;
        autoLayout(state);
        requestDraw(state);
        saveToHistory(state);
      }
    };
    state.renameInput.onkeydown = (event) => {
      if (event.key === "Enter") {
        state.renameInput.blur();
      } else if (event.key === "Escape") {
        state.renameInput.value = originalText;
        state.renameInput.blur();
      }
    };
  }

  function setupCanvasEvents(state) {
    state.canvas.addEventListener("mousedown", (e) => {
      const { canvasCoords } = getCanvasRelativeCoords(state, e.clientX, e.clientY);
      beginInteraction(state, e.clientX, e.clientY, canvasCoords.x, canvasCoords.y);
    });
    state.canvas.addEventListener("mousemove", (e) => {
      const { canvasCoords } = getCanvasRelativeCoords(state, e.clientX, e.clientY);
      updatePan(state, e.clientX, e.clientY);
      updateDrag(state, canvasCoords.x, canvasCoords.y);
    });
    state.canvas.addEventListener("mouseup", () => {
      state.isPanning = false;
      completeDrag(state);
    });
    state.canvas.addEventListener("click", (e) => {
      if (Date.now() - state.lastDragEndAt < 150) return;
      const { canvasCoords } = getCanvasRelativeCoords(state, e.clientX, e.clientY);
      const hitNode = findNodeAt(state, canvasCoords.x, canvasCoords.y);
      if (!hitNode) {
        state.selectedNode = null;
        updateDeleteButton(state);
        requestDraw(state);
        const attachPanel = document.getElementById("attachPanel");
        if (attachPanel) { attachPanel.classList.remove("visible"); if (state.attachBtn) state.attachBtn.classList.remove("active"); }
        return;
      }
      state.selectedNode = hitNode;
      updateDeleteButton(state);
      requestDraw(state);
      refreshAttachPanelIfOpen(state);
    });
    state.canvas.addEventListener(
      "wheel",
      (e) => {
        e.preventDefault();
        const zoomAmount = -e.deltaY * 0.001;
        const { canvasCoords } = getCanvasRelativeCoords(state, e.clientX, e.clientY);
        const newScale = Math.min(Math.max(state.viewScale * (1 + zoomAmount), 0.1), 4);
        state.viewOffsetX -= canvasCoords.x * newScale - canvasCoords.x * state.viewScale;
        state.viewOffsetY -= canvasCoords.y * newScale - canvasCoords.y * state.viewScale;
        state.viewScale = newScale;
        requestDraw(state);
      },
      { passive: false }
    );
    state.canvas.addEventListener(
      "touchstart",
      (e) => {
        if (e.touches.length === 2) {
          state.lastTouchDist = getTouchDistance(e);
          return;
        }
        const touch = e.touches[0];
        const { canvasCoords } = getCanvasRelativeCoords(state, touch.clientX, touch.clientY);
        beginInteraction(state, touch.clientX, touch.clientY, canvasCoords.x, canvasCoords.y, {
          allowDoubleTapRename: true
        });
      },
      { passive: false }
    );
    state.canvas.addEventListener(
      "touchmove",
      (e) => {
        e.preventDefault();
        if (handlePinchZoom(state, e)) return;
        if (e.touches.length === 0) return;
        const touch = e.touches[0];
        const { canvasCoords } = getCanvasRelativeCoords(state, touch.clientX, touch.clientY);
        updatePan(state, touch.clientX, touch.clientY);
        updateDrag(state, canvasCoords.x, canvasCoords.y, 10);
      },
      { passive: false }
    );
    state.canvas.addEventListener("touchend", () => {
      state.isPanning = false;
      state.lastTouchDist = null;
      completeDrag(state);
    });
    state.canvas.addEventListener("dblclick", (e) => {
      const { canvasCoords } = getCanvasRelativeCoords(state, e.clientX, e.clientY);
      const hitNode = findNodeAt(state, canvasCoords.x, canvasCoords.y);
      if (hitNode) showRenameInput(state, hitNode);
    });
    window.addEventListener("resize", () => {
      setCanvasSize(state);
      requestDraw(state);
    });
  }

  function setupToolbar(state) {
    function updateToolbarToggle() {
      if (window.innerWidth <= 600) {
        state.toolbarToggle.style.display = "inline-flex";
      } else {
        state.toolbarToggle.style.display = "none";
        state.toolbar.classList.remove("hidden");
      }
    }
    updateToolbarToggle();
    window.addEventListener("resize", updateToolbarToggle);
    state.toolbarToggle.addEventListener("click", () => {
      state.toolbar.classList.toggle("hidden");
    });
    if ("visualViewport" in window) {
      window.visualViewport.addEventListener("resize", () => {
        const keyboardVisible = window.visualViewport.height < window.innerHeight * 0.8;
        state.toolbar.classList.toggle("keyboard-active", keyboardVisible);
      });
    } else {
      document.addEventListener("focusin", (e) => {
        if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") {
          state.toolbar.classList.add("keyboard-active");
        }
      });
      document.addEventListener("focusout", (e) => {
        if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") {
          state.toolbar.classList.remove("keyboard-active");
        }
      });
    }
  }

  function setupKeyboardShortcuts(state) {
    document.addEventListener("keydown", (e) => {
      const targetTag = e.target && e.target.tagName ? e.target.tagName.toLowerCase() : "";
      const typing = targetTag === "input" || targetTag === "textarea" || e.target.isContentEditable;
      if (typing) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") { e.preventDefault(); undo(state); return; }
      if (e.key === "Delete" || e.key === "Backspace") { e.preventDefault(); deleteNode(state); return; }
      if (e.key.toLowerCase() === "n") { e.preventDefault(); addNode(state); return; }
      if (e.key.toLowerCase() === "c") { e.preventDefault(); centerMindmap(state, () => requestDraw(state)); return; }
      if (e.key.toLowerCase() === "l") { e.preventDefault(); cycleLayoutMode(state); return; }
      if (e.key.toLowerCase() === "f") { e.preventDefault(); toggleFocusSelected(state); return; }
      if (e.key.toLowerCase() === "p") { e.preventDefault(); togglePinSelected(state); return; }
      if (e.key.toLowerCase() === "x") { e.preventDefault(); toggleCollapseSelected(state); return; }
      if (e.key.toLowerCase() === "t") { e.preventDefault(); cycleBranchTheme(state); }
    });
  }

  // ── Attachment panel ────────────────────────────────────────────────────────

  const ATTACH_MAX_BYTES = 25 * 1024 * 1024; // 25 MB

  function formatBytes(bytes) {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  }

  function getFileExt(name) {
    const parts = name.split(".");
    return parts.length > 1 ? parts[parts.length - 1].toUpperCase().slice(0, 4) : "FILE";
  }

  function isImageType(type) {
    return type && type.startsWith("image/");
  }

  function openAttachLightbox(att) {
    const lb = document.getElementById("attachLightbox");
    const img = document.getElementById("attachLightboxImg");
    const fname = document.getElementById("attachLightboxFilename");
    if (!lb || !img) return;
    img.src = att.data;
    img.alt = att.name;
    if (fname) fname.textContent = att.name;
    lb.classList.add("visible");
  }

  function closeAttachLightbox() {
    const lb = document.getElementById("attachLightbox");
    if (lb) lb.classList.remove("visible");
  }

  function downloadAttachment(att) {
    const a = document.createElement("a");
    a.href = att.data;
    a.download = att.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  function renderAttachList(state) {
    const listEl = document.getElementById("attachList");
    if (!listEl) return;
    const node = state.selectedNode;
    const atts = (node && node.attachments) ? node.attachments : [];
    if (atts.length === 0) {
      listEl.innerHTML = "<div class=\"attach-empty\">No attachments yet.</div>";
      return;
    }
    listEl.innerHTML = "";
    for (const att of atts) {
      const item = document.createElement("div");
      item.className = "attach-item";
      // Thumbnail or icon
      let thumbHtml;
      if (isImageType(att.type)) {
        thumbHtml = `<img class="attach-item-thumb" src="${escHtml(att.data)}" alt="${escHtml(att.name)}" />`;
      } else {
        thumbHtml = `<div class="attach-item-icon">${escHtml(getFileExt(att.name))}</div>`;
      }
      item.innerHTML = `
        ${thumbHtml}
        <div class="attach-item-info">
          <div class="attach-item-name" title="${escHtml(att.name)}">${escHtml(att.name)}</div>
          <div class="attach-item-size">${formatBytes(att.size)}</div>
        </div>
        <div class="attach-item-actions">
          <button class="attach-view-btn" data-id="${escHtml(att.id)}" aria-label="View" title="View / Download">
            <svg viewBox="0 0 24 24" fill="none" width="13" height="13"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/></svg>
          </button>
          <button class="attach-remove-btn" data-id="${escHtml(att.id)}" aria-label="Remove">
            <svg viewBox="0 0 24 24" fill="none" width="12" height="12"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg>
          </button>
        </div>`;
      listEl.appendChild(item);
    }
    // Bind view and remove
    listEl.querySelectorAll(".attach-view-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.id;
        const att = (node.attachments || []).find((a) => a.id === id);
        if (!att) return;
        if (isImageType(att.type)) {
          openAttachLightbox(att);
        } else {
          downloadAttachment(att);
        }
      });
    });
    listEl.querySelectorAll(".attach-remove-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.id;
        if (!node) return;
        _imgCache.delete(id);
        _dropAttach(id);  // remove from localStorage + IDB
        node.attachments = (node.attachments || []).filter((a) => a.id !== id);
        renderAttachList(state);
        requestDraw(state);
        saveToHistory(state);
      });
    });
  }

  function handleAttachFiles(state, files) {
    const node = state.selectedNode;
    if (!node) return;
    let added = 0;
    let skipped = 0;
    const process = (file) => new Promise((resolve) => {
      if (file.size > ATTACH_MAX_BYTES) {
        skipped++;
        resolve();
        return;
      }
      const reader = new FileReader();
      reader.onload = (evt) => {
        if (!node.attachments) node.attachments = [];
        const att = {
          id: "att_" + Date.now() + "_" + Math.random().toString(36).slice(2, 7),
          name: file.name,
          type: file.type || "application/octet-stream",
          size: file.size,
          data: evt.target.result
        };
        node.attachments.push(att);
        _persistAttach(att.id, att.data);  // persist to localStorage (falls back to IDB for large files)
        added++;
        resolve();
      };
      reader.readAsDataURL(file);
    });
    Promise.all(Array.from(files).map(process)).then(() => {
      renderAttachList(state);
      requestDraw(state);
      saveToHistory(state);
      if (skipped > 0) {
        showStatus(state, `${skipped} file(s) skipped — exceeds 25 MB limit`);
      } else if (added > 0) {
        showStatus(state, `${added} attachment(s) added`);
      }
    });
  }

  function setupAttachPanel(state) {
    const panel = document.getElementById("attachPanel");
    const closeBtn = document.getElementById("attachPanelClose");
    const fileInput = document.getElementById("attachFileInput");
    const dropZone = document.getElementById("attachDropZone");
    const lbClose = document.getElementById("attachLightboxClose");
    const lbBackdrop = document.getElementById("attachLightboxBackdrop");
    if (!panel) return;

    if (closeBtn) {
      closeBtn.addEventListener("click", () => {
        panel.classList.remove("visible");
        if (state.attachBtn) state.attachBtn.classList.remove("active");
      });
    }
    if (fileInput) {
      fileInput.addEventListener("change", () => {
        if (fileInput.files && fileInput.files.length > 0) {
          handleAttachFiles(state, fileInput.files);
          fileInput.value = "";
        }
      });
    }
    if (dropZone) {
      dropZone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropZone.classList.add("dragover");
      });
      dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragover"));
      dropZone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropZone.classList.remove("dragover");
        if (e.dataTransfer && e.dataTransfer.files.length > 0) {
          handleAttachFiles(state, e.dataTransfer.files);
        }
      });
    }
    if (lbClose) lbClose.addEventListener("click", closeAttachLightbox);
    if (lbBackdrop) lbBackdrop.addEventListener("click", closeAttachLightbox);
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeAttachLightbox();
    });
  }

  function toggleAttachPanel(state) {
    const panel = document.getElementById("attachPanel");
    if (!panel) return;
    const node = state.selectedNode;
    if (!node) { showStatus(state, "Select a node first"); return; }
    const isOpen = panel.classList.contains("visible");
    if (isOpen) {
      panel.classList.remove("visible");
      if (state.attachBtn) state.attachBtn.classList.remove("active");
    } else {
      const title = document.getElementById("attachPanelTitle");
      if (title) title.textContent = `Attachments — ${node.text}`;
      renderAttachList(state);
      panel.classList.add("visible");
      if (state.attachBtn) state.attachBtn.classList.add("active");
    }
  }

  function refreshAttachPanelIfOpen(state) {
    const panel = document.getElementById("attachPanel");
    if (panel && panel.classList.contains("visible")) {
      const node = state.selectedNode;
      const title = document.getElementById("attachPanelTitle");
      if (title && node) title.textContent = `Attachments — ${node.text}`;
      renderAttachList(state);
    }
  }

  function bindControls(state) {
    state.addBtn.addEventListener("click", () => addNode(state));
    state.deleteBtn.addEventListener("click", () => deleteNode(state));
    state.centerBtn.addEventListener("click", () => centerMindmap(state, () => requestDraw(state)));
    state.undoBtn.addEventListener("click", () => undo(state));
    state.clearBtn.addEventListener("click", () => clearNodes(state));
    state.saveBtn.addEventListener("click", () => saveToGist(state));
    if (state.loadBtn) state.loadBtn.addEventListener("click", () => loadFromFile(state));
    state.collapseBtn.addEventListener("click", () => toggleCollapseSelected(state));
    state.focusBtn.addEventListener("click", () => toggleFocusSelected(state));
    state.layoutBtn.addEventListener("click", () => cycleLayoutMode(state));
    state.pinBtn.addEventListener("click", () => togglePinSelected(state));
    state.themeBtn.addEventListener("click", () => cycleBranchTheme(state));
    state.savePartBtn.addEventListener("click", () => saveAsGlobalPart(state));
    state.pushPartBtn.addEventListener("click", () => pushPartUpdate(state));
    state.partsBtn.addEventListener("click", () => togglePartsPanel(state));
    state.pinRefBtn.addEventListener("click", () => pinRefInstance(state));
    state.tagBtn.addEventListener("click", () => toggleTagPanel(state));
    if (state.attachBtn) state.attachBtn.addEventListener("click", () => toggleAttachPanel(state));
    if (state.toolbarMinBtn) {
      state.toolbarMinBtn.addEventListener("click", () => {
        state.toolbar.classList.add("minimized");
        if (state.toolbarRevealBtn) state.toolbarRevealBtn.classList.add("visible");
      });
    }
    if (state.toolbarRevealBtn) {
      state.toolbarRevealBtn.addEventListener("click", () => {
        state.toolbar.classList.remove("minimized");
        state.toolbarRevealBtn.classList.remove("visible");
      });
    }
    state.reorderUp.addEventListener("click", () => moveNodeUp(state));
    state.reorderDown.addEventListener("click", () => moveNodeDown(state));
    window.moveNodeUp = () => moveNodeUp(state);
    window.moveNodeDown = () => moveNodeDown(state);
  }

  function initializeFromQuery(state) {
    setupAttachPanel(state);
    const urlParams = new URLSearchParams(window.location.search);
    const gistId = urlParams.get("gistId");
    if (gistId) { loadFromGist(state, gistId); return; }
    if (recoverFromAutosave(state)) return;
    const rootNode = createNode(state, "My Mindmap");
    state.nodes.push(rootNode);
    state.selectedNode = rootNode;
    autoLayout(state);
    centerMindmap(state, () => requestDraw(state));
    saveToHistory(state);
    state.history = [state.history[state.history.length - 1]];
    setUnsavedChanges(state, false);
    updateDeleteButton(state);
  }

  // ── global-map-parts ────────────────────────────────────────────────────────

  const GLOBAL_PARTS_KEY = "mindmap.globalParts.v1";

  function loadGlobalParts() {
    try {
      if (!canUseLocalStorage()) return {};
      const raw = window.localStorage.getItem(GLOBAL_PARTS_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch { return {}; }
  }

  function saveGlobalPartsToStorage(parts) {
    try {
      if (!canUseLocalStorage()) return;
      window.localStorage.setItem(GLOBAL_PARTS_KEY, JSON.stringify(parts));
    } catch {}
  }

  // Build a plain-object subtree from a node (excludes resolved children)
  function buildSubtree(node) {
    return {
      text: node.text,
      attachments: (node.attachments && node.attachments.length > 0) ? node.attachments : undefined,
      children: node.children
        .filter((c) => !c.resolvedFromPart)
        .map((c) => buildSubtree(c))
    };
  }

  // Build subtree from ALL children (for pinned snapshot)
  function buildSubtreeAll(node) {
    return {
      text: node.text,
      attachments: (node.attachments && node.attachments.length > 0) ? node.attachments : undefined,
      children: node.children.map((c) => buildSubtreeAll(c))
    };
  }

  function createNodesFromPartData(state, nodeData, parent) {
    const node = createNode(state, nodeData.text);
    node.parent = parent;
    node.resolvedFromPart = true;
    if (nodeData.attachments && nodeData.attachments.length > 0) {
      node.attachments = nodeData.attachments;
      // Ensure attachment data is persisted so images survive refresh
      for (const att of node.attachments) {
        if (att.data) _persistAttach(att.id, att.data);
      }
    }
    state.nodes.push(node);
    if (parent) {
      parent.children.push(node);
      state.links.push({ from: parent, to: node });
    }
    for (const childData of (nodeData.children || [])) {
      createNodesFromPartData(state, childData, node);
    }
    return node;
  }

  function removeSubtreeFromState(state, node) {
    for (const child of [...node.children]) {
      removeSubtreeFromState(state, child);
    }
    state.links = state.links.filter((l) => l.from !== node && l.to !== node);
    const idx = state.nodes.indexOf(node);
    if (idx > -1) state.nodes.splice(idx, 1);
  }

  function resolveLinkedNodes(state) {
    // Collect attachments added by the user to resolved nodes (keyed by node text),
    // so they survive the tear-down/rebuild cycle that happens on every autoLayout.
    function collectResolvedAttachments(nodes) {
      const map = new Map(); // text -> attachments[]
      function walk(n) {
        if (n.attachments && n.attachments.length > 0) {
          const existing = map.get(n.text);
          if (existing) {
            // Merge, deduplicate by id
            const ids = new Set(existing.map((a) => a.id));
            for (const a of n.attachments) { if (!ids.has(a.id)) existing.push(a); }
          } else {
            map.set(n.text, [...n.attachments]);
          }
        }
        for (const child of n.children) walk(child);
      }
      for (const n of nodes) walk(n);
      return map;
    }

    // After rebuilding, merge saved attachments back into the new resolved nodes.
    function mergeResolvedAttachments(nodes, savedMap) {
      function walk(n) {
        if (savedMap.has(n.text)) {
          const saved = savedMap.get(n.text);
          if (!n.attachments) n.attachments = [];
          const ids = new Set(n.attachments.map((a) => a.id));
          for (const a of saved) { if (!ids.has(a.id)) n.attachments.push(a); }
        }
        for (const child of n.children) walk(child);
      }
      for (const n of nodes) walk(n);
    }

    const parts = loadGlobalParts();
    const linkedNodes = state.nodes.filter((n) => n.linkedPartId);
    for (const node of linkedNodes) {
      const resolvedChildren = node.children.filter((c) => c.resolvedFromPart);
      // Save user-added attachments before tearing down
      const savedAttachments = collectResolvedAttachments(resolvedChildren);
      // Track the selected node so we can re-point after rebuild
      const selectedWasResolved = state.selectedNode && resolvedChildren.some(
        (c) => c === state.selectedNode || c.children.some(function findIn(n) {
          return n === state.selectedNode || n.children.some(findIn);
        })
      );
      const selectedText = selectedWasResolved && state.selectedNode ? state.selectedNode.text : null;
      for (const child of resolvedChildren) removeSubtreeFromState(state, child);
      node.children = node.children.filter((c) => !c.resolvedFromPart);
      // Pinned instances use their stored snapshot; live instances use the registry
      let subtreeData;
      if (node.instanceState === "pinned" && node.pinnedSnapshot) {
        subtreeData = node.pinnedSnapshot;
      } else {
        const part = parts[node.linkedPartId];
        if (!part) continue;
        subtreeData = part.subtree;
      }
      for (const childData of (subtreeData.children || [])) {
        createNodesFromPartData(state, childData, node);
      }
      // Restore user-added attachments into the newly created resolved nodes
      if (savedAttachments.size > 0) {
        const newResolved = node.children.filter((c) => c.resolvedFromPart);
        mergeResolvedAttachments(newResolved, savedAttachments);
      }
      // Re-point selectedNode to the new counterpart (matched by text)
      if (selectedText !== null) {
        function findByText(nodes, text) {
          for (const n of nodes) {
            if (n.text === text) return n;
            const found = findByText(n.children, text);
            if (found) return found;
          }
          return null;
        }
        const newSel = findByText(node.children.filter((c) => c.resolvedFromPart), selectedText);
        if (newSel) state.selectedNode = newSel;
      }
    }
  }

  // Returns { live, pinned, total, nodes } for dependency tracking
  function getPartDependencies(state, partId) {
    const refs = state.nodes.filter((n) => n.linkedPartId === partId);
    const live = refs.filter((n) => n.instanceState !== "pinned");
    const pinned = refs.filter((n) => n.instanceState === "pinned");
    return { live: live.length, pinned: pinned.length, total: refs.length, nodes: refs };
  }

  function getNodeBreadcrumb(node) {
    const parts = [];
    let cur = node;
    while (cur) { parts.unshift(cur.text); cur = cur.parent; }
    return parts.join(" › ");
  }

  function saveAsGlobalPart(state) {
    if (!state.selectedNode) { showStatus(state, "Select a node first"); return; }
    if (state.selectedNode.resolvedFromPart) {
      showStatus(state, "Cannot save a linked child as a Global Part");
      return;
    }
    const name = window.prompt("Name for this Global Part:", state.selectedNode.text);
    if (!name || !name.trim()) return;
    const partId = "part_" + Date.now();
    const parts = loadGlobalParts();
    parts[partId] = {
      id: partId,
      name: name.trim(),
      subtree: buildSubtree(state.selectedNode),
      tags: [],
      createdAt: Date.now()
    };
    saveGlobalPartsToStorage(parts);
    state.selectedNode.isGlobalPartSource = partId;
    requestDraw(state);
    updatePartButtons(state);
    renderPartsList(state);
    showStatus(state, "Saved \"" + name.trim() + "\" as a Global Part");
  }

  function insertGlobalPartReference(state, partId) {
    const parts = loadGlobalParts();
    const part = parts[partId];
    if (!part) { showStatus(state, "Global Part not found"); return; }
    if (!state.selectedNode) { showStatus(state, "Select a parent node first"); return; }
    if (state.selectedNode.resolvedFromPart) {
      showStatus(state, "Cannot insert reference inside a linked reference");
      return;
    }
    const node = createNode(state, part.name);
    node.parent = state.selectedNode;
    node.linkedPartId = partId;
    node.instanceState = "live";
    node.pinnedSnapshot = null;
    if (state.selectedNode.collapsed) state.selectedNode.collapsed = false;
    state.selectedNode.children.push(node);
    state.links.push({ from: state.selectedNode, to: node });
    state.nodes.push(node);
    state.selectedNode = node;
    autoLayout(state);
    requestDraw(state);
    updateDeleteButton(state);
    saveToHistory(state);
    showStatus(state, "Inserted linked reference to \"" + part.name + "\"");
  }

  // Toggle pin/unpin for the selected linked-reference node
  function pinRefInstance(state) {
    const node = state.selectedNode;
    if (!node || !node.linkedPartId) {
      showStatus(state, "Select a linked reference node to pin/unpin");
      return;
    }
    if (node.instanceState === "pinned") {
      node.instanceState = "live";
      node.pinnedSnapshot = null;
      resolveLinkedNodes(state);
      autoLayout(state);
      requestDraw(state);
      updatePartButtons(state);
      saveToHistory(state);
      showStatus(state, "\"" + node.text + "\" is now live-linked — updates with source");
    } else {
      const parts = loadGlobalParts();
      const part = parts[node.linkedPartId];
      if (!part) { showStatus(state, "Global Part not found"); return; }
      node.instanceState = "pinned";
      node.pinnedSnapshot = JSON.parse(JSON.stringify(part.subtree));
      requestDraw(state);
      updatePartButtons(state);
      saveToHistory(state);
      showStatus(state, "\"" + node.text + "\" pinned at current version");
    }
  }

  // Show impact preview modal, then call onConfirm if user proceeds
  function showImpactModal(state, partId, onConfirm) {
    const parts = loadGlobalParts();
    const part = parts[partId];
    if (!part) return;
    const deps = getPartDependencies(state, partId);
    const modal = document.getElementById("impactModal");
    const titleEl = document.getElementById("impactModalTitle");
    const body = document.getElementById("impactModalBody");
    const confirmBtn = document.getElementById("impactConfirmBtn");
    const cancelBtn = document.getElementById("impactCancelBtn");
    if (!modal) { onConfirm(); return; }

    if (titleEl) titleEl.textContent = "Push Update: " + part.name;

    let html = "";
    if (deps.live > 0) {
      html += "<div class=\"impact-group impact-live\">";
      html += "<span class=\"impact-group-label\">Will update (" + deps.live + " live-linked)</span><ul>";
      deps.nodes.filter((n) => n.instanceState !== "pinned").forEach((n) => {
        html += "<li>" + escHtml(getNodeBreadcrumb(n)) + "</li>";
      });
      html += "</ul></div>";
    } else {
      html += "<p class=\"impact-no-live\">No live-linked instances — nothing to update.</p>";
    }
    if (deps.pinned > 0) {
      html += "<div class=\"impact-group impact-pinned\">";
      html += "<span class=\"impact-group-label\">Will NOT update (" + deps.pinned + " pinned)</span><ul>";
      deps.nodes.filter((n) => n.instanceState === "pinned").forEach((n) => {
        html += "<li>" + escHtml(getNodeBreadcrumb(n)) + "</li>";
      });
      html += "</ul></div>";
    }
    if (body) body.innerHTML = html;
    modal.classList.add("visible");

    const cleanup = () => modal.classList.remove("visible");
    if (confirmBtn) confirmBtn.onclick = () => { cleanup(); onConfirm(); };
    if (cancelBtn) cancelBtn.onclick = () => { cleanup(); showStatus(state, "Push cancelled"); };
  }

  function pushPartUpdate(state) {
    if (!state.selectedNode || !state.selectedNode.isGlobalPartSource) {
      showStatus(state, "Select a Global Part source node first");
      return;
    }
    const partId = state.selectedNode.isGlobalPartSource;
    const parts = loadGlobalParts();
    if (!parts[partId]) { showStatus(state, "Global Part not found in registry"); return; }
    showImpactModal(state, partId, () => {
      const freshParts = loadGlobalParts();
      if (!freshParts[partId]) return;
      freshParts[partId].subtree = buildSubtree(state.selectedNode);
      freshParts[partId].updatedAt = Date.now();
      saveGlobalPartsToStorage(freshParts);
      resolveLinkedNodes(state);
      autoLayout(state);
      requestDraw(state);
      renderPartsList(state);
      showStatus(state, "Updated all live references to \"" + freshParts[partId].name + "\"");
    });
  }

  function deleteGlobalPart(state, partId) {
    const parts = loadGlobalParts();
    if (!parts[partId]) return;
    const name = parts[partId].name;
    delete parts[partId];
    saveGlobalPartsToStorage(parts);
    for (const node of state.nodes) {
      if (node.isGlobalPartSource === partId) node.isGlobalPartSource = null;
      if (node.linkedPartId === partId) node.linkedPartId = null;
    }
    resolveLinkedNodes(state);
    autoLayout(state);
    requestDraw(state);
    updatePartButtons(state);
    renderPartsList(state);
    showStatus(state, "Deleted Global Part \"" + name + "\"");
  }

  // ── Part tags ──

  function addTagToPart(state, partId, tag) {
    const t = tag.trim().toLowerCase();
    if (!t) return;
    const parts = loadGlobalParts();
    if (!parts[partId]) return;
    if (!parts[partId].tags) parts[partId].tags = [];
    if (!parts[partId].tags.includes(t)) {
      parts[partId].tags.push(t);
      saveGlobalPartsToStorage(parts);
      renderPartsList(state);
    }
  }

  function removeTagFromPart(state, partId, tag) {
    const parts = loadGlobalParts();
    if (!parts[partId]) return;
    parts[partId].tags = (parts[partId].tags || []).filter((t) => t !== tag);
    saveGlobalPartsToStorage(parts);
    renderPartsList(state);
  }

  // ── HTML/panel helpers ──

  function escHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function renderPartsList(state) {
    const container = document.getElementById("partsList");
    if (!container) return;
    const parts = loadGlobalParts();
    const partIds = Object.keys(parts);
    if (partIds.length === 0) {
      container.innerHTML = "<div class=\"parts-empty\">No global parts yet.<br>Select a node and click <strong>Save Part</strong>.</div>";
      return;
    }
    container.innerHTML = partIds.map((id) => {
      const part = parts[id];
      const deps = getPartDependencies(state, id);
      const depText = deps.total === 0 ? "No references" :
        (deps.live > 0 ? deps.live + " live" : "") +
        (deps.live > 0 && deps.pinned > 0 ? " · " : "") +
        (deps.pinned > 0 ? deps.pinned + " pinned" : "");
      const tagsHtml = (part.tags || []).length > 0
        ? "<div class=\"part-tags\">" +
          (part.tags || []).map((t) =>
            "<span class=\"part-tag-chip\" data-tag=\"" + escHtml(t) + "\" data-part=\"" + id + "\">" +
            escHtml(t) + "<button class=\"part-tag-remove\" aria-label=\"Remove\">×</button></span>"
          ).join("") + "</div>"
        : "";
      // Show thumbnail if root subtree node has an image attachment with data
      const rootAtts = part.subtree && part.subtree.attachments;
      const imgAtt = rootAtts && rootAtts.find((a) => a.type && a.type.startsWith("image/") && a.data);
      const thumbHtml = imgAtt
        ? "<img class=\"part-item-thumb\" src=\"" + escHtml(imgAtt.data) + "\" alt=\"" + escHtml(part.name) + "\" />"
        : "";
      return "<div class=\"part-item\">" +
        thumbHtml +
        "<div class=\"part-item-info\">" +
          "<span class=\"part-item-name\">" + escHtml(part.name) + "</span>" +
          "<span class=\"part-item-meta\">" + depText + "</span>" +
          tagsHtml +
          "<div class=\"part-tag-add-row\">" +
            "<input type=\"text\" class=\"part-tag-input\" data-part=\"" + id + "\" placeholder=\"+ tag\" maxlength=\"20\" autocomplete=\"off\"/>" +
          "</div>" +
        "</div>" +
        "<div class=\"part-item-actions\">" +
          "<button type=\"button\" class=\"part-insert-btn\" data-part-id=\"" + id + "\">" +
            "<svg viewBox=\"0 0 24 24\" fill=\"none\" width=\"11\" height=\"11\"><path d=\"M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/></svg>" +
            "Insert Ref" +
          "</button>" +
          "<button type=\"button\" class=\"part-delete-btn\" data-part-id=\"" + id + "\" title=\"Delete Part\">" +
            "<svg viewBox=\"0 0 24 24\" fill=\"none\" width=\"11\" height=\"11\"><path d=\"M18 6L6 18M6 6l12 12\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\"/></svg>" +
          "</button>" +
        "</div>" +
      "</div>";
    }).join("");
    container.querySelectorAll(".part-insert-btn").forEach((btn) => {
      btn.addEventListener("click", () => insertGlobalPartReference(state, btn.dataset.partId));
    });
    container.querySelectorAll(".part-delete-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const part = loadGlobalParts()[btn.dataset.partId];
        if (part && window.confirm("Delete Global Part \"" + part.name + "\"?\nAll linked references will be unlinked.")) {
          deleteGlobalPart(state, btn.dataset.partId);
        }
      });
    });
    container.querySelectorAll(".part-tag-remove").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const chip = btn.parentElement;
        removeTagFromPart(state, chip.dataset.part, chip.dataset.tag);
      });
    });
    container.querySelectorAll(".part-tag-input").forEach((input) => {
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === ",") {
          e.preventDefault();
          addTagToPart(state, input.dataset.part, input.value);
          input.value = "";
        }
      });
    });
  }

  function togglePartsPanel(state) {
    const panel = document.getElementById("partsPanel");
    const isVisible = panel.classList.toggle("visible");
    state.partsBtn.classList.toggle("active", isVisible);
    if (isVisible) renderPartsList(state);
  }

  function setupGlobalPartsPanel(state) {
    const closeBtn = document.getElementById("partsPanelClose");
    if (closeBtn) {
      closeBtn.addEventListener("click", () => {
        document.getElementById("partsPanel").classList.remove("visible");
        state.partsBtn.classList.remove("active");
      });
    }
    renderPartsList(state);
  }

  // ── Node tag panel ──

  function openTagPanel(state) {
    if (!state.selectedNode) { showStatus(state, "Select a node to add tags"); return; }
    renderTagChips(state);
    document.getElementById("tagPanel").classList.add("visible");
    state.tagBtn.classList.add("active");
    const input = document.getElementById("tagInput");
    if (input) { input.value = ""; input.focus(); }
  }

  function closeTagPanel(state) {
    document.getElementById("tagPanel").classList.remove("visible");
    state.tagBtn.classList.remove("active");
  }

  function toggleTagPanel(state) {
    const panel = document.getElementById("tagPanel");
    if (panel.classList.contains("visible")) closeTagPanel(state); else openTagPanel(state);
  }

  function renderTagChips(state) {
    const node = state.selectedNode;
    const title = document.getElementById("tagPanelTitle");
    const chips = document.getElementById("tagChips");
    if (!chips) return;
    if (!node) { if (chips) chips.innerHTML = "<span class=\"tag-chips-empty\">No node selected</span>"; return; }
    if (title) {
      const t = node.text.length > 22 ? node.text.slice(0, 22) + "…" : node.text;
      title.textContent = "Tags: " + t;
    }
    const tags = node.tags || [];
    if (tags.length === 0) {
      chips.innerHTML = "<span class=\"tag-chips-empty\">No tags — type below and press Enter</span>";
    } else {
      chips.innerHTML = tags.map((tag) =>
        "<span class=\"tag-chip\" data-tag=\"" + escHtml(tag) + "\">" +
        escHtml(tag) +
        "<button class=\"tag-chip-remove\" aria-label=\"Remove tag\">×</button></span>"
      ).join("");
      chips.querySelectorAll(".tag-chip-remove").forEach((btn) => {
        btn.addEventListener("click", () => {
          const tag = btn.parentElement.dataset.tag;
          if (state.selectedNode) {
            state.selectedNode.tags = (state.selectedNode.tags || []).filter((t) => t !== tag);
            renderTagChips(state);
            requestDraw(state);
            saveToHistory(state);
          }
        });
      });
    }
  }

  function setupTagPanel(state) {
    const closeBtn = document.getElementById("tagPanelClose");
    const input = document.getElementById("tagInput");
    if (closeBtn) closeBtn.addEventListener("click", () => closeTagPanel(state));
    if (input) {
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === ",") {
          e.preventDefault();
          const tag = input.value.trim().toLowerCase().replace(/[,#]/g, "");
          if (tag && state.selectedNode) {
            if (!state.selectedNode.tags) state.selectedNode.tags = [];
            if (!state.selectedNode.tags.includes(tag)) {
              state.selectedNode.tags.push(tag);
              renderTagChips(state);
              requestDraw(state);
              saveToHistory(state);
            }
            input.value = "";
          }
        }
        if (e.key === "Escape") closeTagPanel(state);
      });
    }
    document.addEventListener("keydown", (ev) => {
      const tag2 = ev.target && ev.target.tagName ? ev.target.tagName.toLowerCase() : "";
      const typing = tag2 === "input" || tag2 === "textarea" || ev.target.isContentEditable;
      if (!typing && ev.key === "t") { ev.preventDefault(); toggleTagPanel(state); }
    });
    document.addEventListener("click", (ev) => {
      const panel = document.getElementById("tagPanel");
      if (panel && panel.classList.contains("visible")) {
        if (!panel.contains(ev.target) && !state.tagBtn.contains(ev.target)) closeTagPanel(state);
      }
    });
  }

  // ── search ─────────────────────────────────────────────────────────────────

  function setupSearch(state) {
    const searchInput = document.getElementById("searchInput");
    const searchClear = document.getElementById("searchClear");
    const searchResults = document.getElementById("searchResults");

    function escapeHtml(s) {
      return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }

    function getNodePath(node) {
      const parts = [];
      let current = node.parent;
      while (current) {
        parts.unshift(current.text);
        current = current.parent;
      }
      return parts;
    }

    function navigateToResult(id) {
      const node = state.nodes.find((n) => n.id === id);
      if (!node) return;
      state.selectedNode = node;
      updateDeleteButton(state);
      centerMindmap(state, () => requestDraw(state));
    }

    function renderResults(matches, partMatches, query) {
      const hasNodes = matches.length > 0;
      const hasParts = partMatches.length > 0;

      if (!hasNodes && !hasParts) {
        searchResults.innerHTML = `<div class="search-empty">No results for "${escapeHtml(query)}"</div>`;
        searchResults.classList.add("visible");
        return;
      }

      const totalCount = matches.length + partMatches.length;
      let html = `<div class="search-count">${totalCount} result${totalCount !== 1 ? "s" : ""}</div>`;

      if (hasNodes) {
        html += matches.map((n) => {
          const nodePath = getNodePath(n);
          const badge = n.resolvedFromPart
            ? `<span class="search-badge search-badge-resolved">linked</span>`
            : n.linkedPartId
              ? `<span class="search-badge search-badge-ref">ref</span>`
              : "";
          const pathHtml =
            nodePath.length > 0
              ? `<span class="search-path">${nodePath.map(escapeHtml).join(" › ")}</span>`
              : "";
          const label = n.numbering ? `${n.numbering} ${n.text}` : n.text;
          return `<div class="search-result-item" data-id="${n.id}" role="option" tabindex="0">
            <span class="search-text">${escapeHtml(label)}</span>${badge}
            ${pathHtml}
          </div>`;
        }).join("");
      }

      if (hasParts) {
        html += `<div class="search-section-label">Global Parts</div>`;
        html += partMatches.map((part) => {
          const sourceNode = state.nodes.find((n) => n.isGlobalPartSource === part.id);
          const hint = sourceNode
            ? `<span class="search-path">Source on canvas</span>`
            : `<span class="search-path">Not on canvas — insert a reference</span>`;
          return `<div class="search-result-item search-result-part" data-part-id="${escapeHtml(part.id)}" role="option" tabindex="0">
            <span class="search-text">${escapeHtml(part.name)}</span><span class="search-badge search-badge-part">part</span>
            ${hint}
          </div>`;
        }).join("");
      }

      searchResults.innerHTML = html;
      searchResults.classList.add("visible");

      searchResults.querySelectorAll(".search-result-item:not(.search-result-part)").forEach((el) => {
        const id = parseInt(el.dataset.id, 10);
        const handler = () => navigateToResult(id);
        el.addEventListener("click", handler);
        el.addEventListener("keydown", (e) => {
          if (e.key === "Enter" || e.key === " ") { e.preventDefault(); handler(); }
        });
      });

      searchResults.querySelectorAll(".search-result-part").forEach((el) => {
        const partId = el.dataset.partId;
        const handler = () => {
          const sourceNode = state.nodes.find((n) => n.isGlobalPartSource === partId);
          if (sourceNode) {
            navigateToResult(sourceNode.id);
          } else {
            showStatus(state, "Source not on canvas — select a node and use Insert Ref from the Parts panel.");
          }
          searchResults.classList.remove("visible");
        };
        el.addEventListener("click", handler);
        el.addEventListener("keydown", (e) => {
          if (e.key === "Enter" || e.key === " ") { e.preventDefault(); handler(); }
        });
      });
    }

    function doSearch(query) {
      const q = query.trim().toLowerCase();
      state.searchMatchIds.clear();

      if (!q) {
        searchResults.innerHTML = "";
        searchResults.classList.remove("visible");
        searchClear.style.display = "none";
        requestDraw(state);
        return;
      }

      searchClear.style.display = "flex";

      // Search canvas nodes (includes resolvedFromPart children already in state.nodes)
      // Tag filter: #tag syntax
      let matches;
      if (q.startsWith("#")) {
        const tagQuery = q.slice(1);
        matches = tagQuery ? state.nodes.filter((n) => (n.tags || []).some((t) => t.includes(tagQuery))) : [];
      } else {
        matches = state.nodes.filter((n) => n.text.toLowerCase().includes(q));
      }
      matches.forEach((n) => state.searchMatchIds.add(n.id));

      // Also search the Global Parts registry by part name
      const allParts = loadGlobalParts();
      const partMatches = q.startsWith("#")
        ? Object.values(allParts).filter((p) => (p.tags || []).some((t) => t.includes(q.slice(1))))
        : Object.values(allParts).filter((p) => p.name.toLowerCase().includes(q));

      requestDraw(state);
      renderResults(matches, partMatches, query);
    }

    searchInput.addEventListener("input", (e) => doSearch(e.target.value));

    searchInput.addEventListener("focus", () => {
      if (searchInput.value.trim()) {
        searchResults.classList.add("visible");
      }
    });

    searchClear.addEventListener("click", () => {
      searchInput.value = "";
      doSearch("");
      searchInput.focus();
    });

    document.addEventListener("click", (e) => {
      const bar = document.getElementById("searchBar");
      if (!bar.contains(e.target) && !searchResults.contains(e.target)) {
        searchResults.classList.remove("visible");
      }
    });

    document.addEventListener("keydown", (e) => {
      const targetTag = e.target && e.target.tagName ? e.target.tagName.toLowerCase() : "";
      const typing = targetTag === "input" || targetTag === "textarea" || e.target.isContentEditable;
      if (!typing && e.key === "/") {
        e.preventDefault();
        searchInput.focus();
        searchInput.select();
        return;
      }
      if (e.key === "Escape" && document.activeElement === searchInput) {
        searchInput.value = "";
        doSearch("");
        searchInput.blur();
      }
    });
  }

  // ── main ───────────────────────────────────────────────────────────────────

  function init() {
    const state = createAppState();
    setCanvasSize(state);
    window.addEventListener("beforeunload", (e) => {
      if (state.hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = "";
      }
    });
    bindControls(state);
    setupToolbar(state);
    setupKeyboardShortcuts(state);
    setupSearch(state);
    setupGlobalPartsPanel(state);
    setupTagPanel(state);
    setupCanvasEvents(state);
    initializeFromQuery(state);
    updateDeleteButton(state);
    requestDraw(state);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
